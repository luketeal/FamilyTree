// Relationship dialogs, identify phantom, delete confirms, advanced search, people list, empty.

// ─── Add relationship (multi-step) ───────────────────────
function MAddRelationship({ step = 1 }) {
  const Stepper = () => (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center', fontFamily: M.mono, fontSize: 10, color: M.ink3, letterSpacing: 0.4 }}>
      {['TYPE', 'PERSON', 'DETAILS'].map((s, i) => (
        <React.Fragment key={s}>
          <span style={{
            padding: '2px 7px', borderRadius: 3,
            background: i + 1 === step ? M.coralBg : 'transparent',
            color: i + 1 === step ? M.coral : (i + 1 < step ? M.ink2 : M.ink4),
            border: i + 1 === step ? `1px solid ${M.coralLine}` : `1px solid transparent`,
            fontWeight: 600,
          }}>{i + 1}. {s}</span>
          {i < 2 && <span style={{ color: M.ink5 }}>›</span>}
        </React.Fragment>
      ))}
    </div>
  );

  const RelOption = ({ icon, title, sub, picked }) => (
    <div style={{
      padding: '11px 13px', borderRadius: 7,
      border: `1.5px solid ${picked ? M.coral : M.line2}`,
      background: picked ? M.coralBg : M.paper,
      display: 'flex', gap: 11, alignItems: 'flex-start', cursor: 'pointer',
    }}>
      <div style={{
        width: 30, height: 30, borderRadius: 6, flexShrink: 0,
        background: picked ? M.coral : M.paper2, color: picked ? '#fff' : M.ink2,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}><Icon name={icon} size={16} /></div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: M.serif, fontSize: 14, fontWeight: 600, color: M.ink }}>{title}</div>
        <div style={{ fontSize: 11, color: M.ink3, marginTop: 2 }}>{sub}</div>
      </div>
      {picked && <Icon name="check" size={14} color={M.coral} />}
    </div>
  );

  return (
    <Dialog
      title="Add relationship"
      sub={<Stepper />}
      w={460}
      footer={<>
        <Button>Cancel</Button>
        <div style={{ flex: 1 }} />
        {step > 1 && <Button>← Back</Button>}
        <Button variant="primary">{step === 3 ? 'Save' : 'Next →'}</Button>
      </>}
    >
      {step === 1 && (
        <>
          <div style={{ fontSize: 11.5, color: M.ink3, marginBottom: 4 }}>
            From <b>Sarah Chen</b>, link to…
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <RelOption icon="user" title="Parent" sub="Biological, adoptive, or step" picked />
            <RelOption icon="user" title="Child" sub="Biological, adoptive, or step" />
            <RelOption icon="link" title="Sibling" sub="Full or half — auto-derives" />
            <RelOption icon="heart" title="Spouse / partner" sub="Marriage, partnership, ex" />
          </div>
          <Alert tone="info" icon="info">
            Sibling relationships are usually <b>auto-derived</b> from shared parents. Add a sibling here when parents are unknown.
          </Alert>
        </>
      )}

      {step === 2 && (
        <>
          <Field label="Find or create person">
            <Input icon="search" placeholder="Type a name…" value="James" />
          </Field>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 220, overflowY: 'auto', border: `1px solid ${M.line}`, borderRadius: 7 }}>
            {[
              { n: 'James Park', s: '1933 – 2019 · already in tree', i: 'JP', t: 'neutral', deceased: true },
              { n: 'James Park Jr.', s: '1968 – · Linda&#39;s cousin', i: 'JP', t: 'sand' },
              { n: 'James Chen', s: 'no dates · imported from GEDCOM', i: 'JC', t: 'blue' },
            ].map((p, i) => (
              <div key={i} style={{
                padding: '8px 11px', display: 'flex', alignItems: 'center', gap: 9,
                borderTop: i ? `1px solid ${M.line}` : 'none',
                background: i === 0 ? M.coralBg : 'transparent',
              }}>
                <Avatar size={28} initials={p.i} tone={p.t} deceased={p.deceased} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: M.serif, fontSize: 13, color: M.ink, fontWeight: 600 }} dangerouslySetInnerHTML={{ __html: p.n }} />
                  <div style={{ fontSize: 10.5, color: M.ink3, marginTop: 1 }} dangerouslySetInnerHTML={{ __html: p.s }} />
                </div>
                {i === 0 && <Icon name="check" size={14} color={M.coral} />}
              </div>
            ))}
            <div style={{ padding: '9px 11px', borderTop: `1px solid ${M.line}`, color: M.coral, fontSize: 12, display: 'flex', alignItems: 'center', gap: 7, fontWeight: 500 }}>
              <Icon name="plus" size={12} /> Create new person &ldquo;James&rdquo;
            </div>
          </div>
        </>
      )}

      {step === 3 && (
        <>
          <Alert tone="info">
            Adding <b>James Park</b> as <b>parent</b> of <b>Sarah Chen</b>.
          </Alert>
          <Field label="Relationship type">
            <Segmented full items={['Biological', 'Adoptive', 'Step', 'Foster']} active="Biological" />
          </Field>
          <Field label="Certainty">
            <Segmented full items={['Confirmed', 'Likely', 'Speculative']} active="Confirmed" />
          </Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <Field label="Start (e.g. adoption date)"><Input placeholder="optional" /></Field>
            <Field label="End"><Input placeholder="—" /></Field>
          </div>
          <Field label="Source / note"><Textarea placeholder="Birth certificate, family memory, etc." rows={3} /></Field>
        </>
      )}
    </Dialog>
  );
}

// ─── Add marriage dialog ──────────────────────────────────
function MAddMarriage() {
  return (
    <Dialog
      title="Add marriage"
      sub="Sarah Chen ⇿ Alex Tan"
      w={440}
      footer={<>
        <Button>Cancel</Button>
        <div style={{ flex: 1 }} />
        <Button variant="primary">Save marriage</Button>
      </>}
    >
      <Field label="Status">
        <Segmented full items={['Married', 'Partnered', 'Divorced', 'Widowed', 'Engaged']} active="Married" />
      </Field>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <Field label="Marriage date"><Input value="2015-09-12" icon="cake" /></Field>
        <Field label="Place"><Input value="Boston, MA" icon="map" /></Field>
        <Field label="End date"><Input placeholder="—" /></Field>
        <Field label="Reason ended"><Select value="—" /></Field>
      </div>
      <Field label="Note">
        <Textarea placeholder="Ceremony details, witnesses, etc." rows={3} />
      </Field>
      <Alert tone="info" icon="info">
        Children of this couple will inherit <b>both</b> parents automatically. Step relationships are derived for spouses&#39; existing kids.
      </Alert>
    </Dialog>
  );
}

// ─── Identify phantom dialog ─────────────────────────────
function MIdentifyPhantom() {
  return (
    <Dialog
      title="Identify unknown parent"
      sub="Linking 2 inferred children: Sarah Chen, Michael Chen"
      w={460}
      footer={<>
        <Button>Cancel</Button>
        <div style={{ flex: 1 }} />
        <Button>Leave as Unknown</Button>
        <Button variant="primary">Merge into selected</Button>
      </>}
    >
      <Field label="Find existing person">
        <Input icon="search" placeholder="Search tree…" value="Margaret" />
      </Field>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, border: `1px solid ${M.line}`, borderRadius: 7 }}>
        {[
          { n: 'Margaret Chen', s: '1932 – 2015 · already mother of David', i: 'MC', t: 'rose', d: true, picked: true },
          { n: 'Margaret Park', s: '1940 – · cousin via Linda', i: 'MP', t: 'sand' },
        ].map((p, i) => (
          <div key={i} style={{
            padding: '9px 12px', display: 'flex', alignItems: 'center', gap: 10,
            borderTop: i ? `1px solid ${M.line}` : 'none',
            background: p.picked ? M.coralBg : 'transparent',
          }}>
            <Avatar size={30} initials={p.i} tone={p.t} deceased={p.d} />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: M.serif, fontSize: 13, color: M.ink, fontWeight: 600 }}>{p.n}</div>
              <div style={{ fontSize: 10.5, color: M.ink3, marginTop: 1 }}>{p.s}</div>
            </div>
            {p.picked && <Icon name="check" size={14} color={M.coral} />}
          </div>
        ))}
      </div>

      <div style={{ borderTop: `1px solid ${M.line}`, paddingTop: 12, marginTop: 4 }}>
        <div style={{ fontFamily: M.mono, fontSize: 10, color: M.ink3, letterSpacing: 0.5, fontWeight: 700, marginBottom: 6 }}>OR CREATE NEW</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <Field label="Name"><Input placeholder="e.g. Margaret Chen" /></Field>
          <Field label="Born ~"><Input placeholder="c. 1930" /></Field>
        </div>
      </div>

      <Alert tone="warn" icon="warn">
        Merging will combine sibling links. Existing relationships on the chosen person are preserved; conflicting dates flagged for review.
      </Alert>
    </Dialog>
  );
}

// ─── Delete person confirm ────────────────────────────────
function MDeleteConfirm() {
  return (
    <Dialog
      title="Delete this person?"
      sub={<span style={{ color: M.ink2 }}>Sarah Chen · 1988 –</span>}
      w={420}
      footer={<>
        <Button>Cancel</Button>
        <div style={{ flex: 1 }} />
        <Button variant="destructive" icon={<Icon name="trash" size={13} />}>Delete person</Button>
      </>}
    >
      <Alert tone="danger" icon="warn" title="This will affect 5 relationships">
        <ul style={{ margin: '6px 0 0 14px', padding: 0, fontSize: 12, color: M.ink2, lineHeight: 1.6 }}>
          <li>2 parent links to David Chen, Linda Park</li>
          <li>1 marriage to Alex Tan</li>
          <li>2 child links to Liam, Emma</li>
          <li>1 derived sibling link to Michael Chen will dissolve</li>
        </ul>
      </Alert>

      <Field label="What should happen to relationships?">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {[
            { l: 'Replace with phantom — keep sibling links via inferred unknown parent', picked: true },
            { l: 'Detach all — relationships are removed; tree reflows' },
            { l: 'Merge into another person… (recommended for duplicates)', picked: false },
          ].map((o, i) => (
            <label key={i} style={{
              display: 'flex', alignItems: 'flex-start', gap: 8,
              padding: '8px 11px', border: `1.5px solid ${o.picked ? M.coral : M.line2}`,
              background: o.picked ? M.coralBg : M.paper,
              borderRadius: 6, cursor: 'pointer',
            }}>
              <div style={{
                width: 14, height: 14, borderRadius: '50%', flexShrink: 0, marginTop: 1,
                border: `1.5px solid ${o.picked ? M.coral : M.ink4}`,
                background: M.paper, position: 'relative',
              }}>
                {o.picked && <div style={{ position: 'absolute', inset: 2, borderRadius: '50%', background: M.coral }} />}
              </div>
              <span style={{ fontSize: 12, color: M.ink2, lineHeight: 1.4 }}>{o.l}</span>
            </label>
          ))}
        </div>
      </Field>

      <Field label="Type SARAH CHEN to confirm">
        <Input placeholder="SARAH CHEN" />
      </Field>
    </Dialog>
  );
}

// ─── Delete relationship confirm (smaller) ───────────────
function MDeleteRel() {
  return (
    <Dialog
      title="Remove this relationship?"
      w={380}
      footer={<>
        <Button>Cancel</Button>
        <div style={{ flex: 1 }} />
        <Button variant="destructive">Remove link</Button>
      </>}
    >
      <div style={{
        padding: 12, background: M.paper2, borderRadius: 7, border: `1px solid ${M.line}`,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <PersonChip name="Sarah Chen" sub="1988 –" initials="SC" tone="rose" />
        <Icon name="link" size={14} color={M.ink3} />
        <PersonChip name="David Chen" sub="parent · bio" initials="DC" tone="blue" />
      </div>
      <div style={{ fontSize: 12, color: M.ink2, lineHeight: 1.5 }}>
        Removes the <b>biological parent</b> link only. People remain in the tree. Sibling derivations recompute.
      </div>
      <Field label="Reason (optional)">
        <Select value="Recorded in error" />
      </Field>
    </Dialog>
  );
}

// ─── Advanced search panel ────────────────────────────────
function MSearch() {
  return (
    <div style={{ width: '100%', height: '100%', background: M.paper, fontFamily: M.ui, display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 18px', borderBottom: `1px solid ${M.line}` }}>
        <Input icon="search" value="park" placeholder="Search people, places, dates…" />
        <div style={{ display: 'flex', gap: 6, marginTop: 9, flexWrap: 'wrap' }}>
          <Tag tone="accent">name: park ×</Tag>
          <Tag tone="neutral">born: 1930–1970 ×</Tag>
          <Tag tone="ghost">+ filter</Tag>
        </div>
      </div>

      <div style={{ padding: '12px 18px', borderBottom: `1px solid ${M.line}`, display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontFamily: M.mono, fontSize: 10, color: M.ink3, fontWeight: 700, letterSpacing: 0.4 }}>4 RESULTS</span>
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 11, color: M.ink3 }}>Sort:</span>
        <Select value="Relevance" small />
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        {[
          { n: 'Linda Park', s: '1962 – · mother of Sarah Chen', i: 'LP', t: 'sand', match: 'name' },
          { n: 'James Park', s: '1933 – 2019 · grandfather', i: 'JP', t: 'neutral', d: true, match: 'name' },
          { n: 'Eva Park', s: '1935 – · grandmother', i: 'EP', t: 'sage', match: 'name' },
          { n: 'James Park Jr.', s: '1968 – · cousin', i: 'JP', t: 'blue', match: 'name' },
        ].map((p, i) => (
          <div key={i} style={{
            padding: '12px 18px', display: 'flex', alignItems: 'center', gap: 11,
            borderBottom: `1px solid ${M.line}`, cursor: 'pointer',
          }}>
            <Avatar size={36} initials={p.i} tone={p.t} deceased={p.d} />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: M.serif, fontSize: 14, color: M.ink, fontWeight: 600 }}>
                Linda <mark style={{ background: '#fff3c4', padding: '0 1px' }}>Park</mark>
                {i !== 0 && <span style={{ display: 'none' }}></span>}
              </div>
              <div style={{ fontSize: 11, color: M.ink3, marginTop: 2 }}>{p.s}</div>
            </div>
            <Tag tone="ghost">{p.match}</Tag>
            <Icon name="chev_r" size={12} color={M.ink4} />
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── People list view ─────────────────────────────────────
function MPeopleList() {
  const rows = [
    { n: 'Sarah Chen', d: '1988 –', p: 'Boston, MA', g: 'F', i: 'SC', t: 'rose', rel: '2 parents · 2 kids' },
    { n: 'Michael Chen', d: '1991 –', p: 'San Francisco', g: 'M', i: 'MC', t: 'blue', rel: '2 parents · 0 kids' },
    { n: 'David Chen', d: '1960 –', p: 'Cambridge, MA', g: 'M', i: 'DC', t: 'blue', rel: '2 parents · 2 kids' },
    { n: 'Linda Park', d: '1962 –', p: 'Cambridge, MA', g: 'F', i: 'LP', t: 'sand', rel: '2 parents · 2 kids' },
    { n: 'Margaret Chen', d: '1932 – 2015', p: 'Brookline', g: 'F', i: 'MC', t: 'rose', dec: true, rel: '0 parents · 1 kid' },
    { n: 'Robert Chen', d: '1930 – 2008', p: 'Brookline', g: 'M', i: 'RC', t: 'neutral', dec: true, rel: '0 parents · 1 kid' },
    { n: 'Eva Park', d: '1935 –', p: 'Seoul, KR', g: 'F', i: 'EP', t: 'sage', rel: '0 parents · 1 kid' },
    { n: 'James Park', d: '1933 – 2019', p: 'Seoul, KR', g: 'M', i: 'JP', t: 'neutral', dec: true, rel: '0 parents · 1 kid' },
    { n: 'Alex Tan', d: '1987 –', p: 'Singapore', g: 'M', i: 'AT', t: 'sage', rel: '0 in tree · 2 kids' },
    { n: 'Liam Chen-Tan', d: '2018 –', p: 'Boston, MA', g: 'M', i: 'LC', t: 'sand', rel: '2 parents · bio' },
    { n: 'Emma Chen-Tan', d: '2015 –', p: 'Boston, MA', g: 'F', i: 'EC', t: 'coral', rel: '2 parents · adopted' },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: M.paper, fontFamily: M.ui, display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 22px', borderBottom: `1px solid ${M.line}`, display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ fontFamily: M.serif, fontSize: 18, fontWeight: 600, color: M.ink, letterSpacing: -0.2 }}>People</div>
        <Tag tone="neutral">42 total</Tag>
        <div style={{ flex: 1 }} />
        <Input icon="search" placeholder="Filter…" small style={{ width: 200 }} />
        <Select value="All generations" small />
        <Button size="sm" variant="primary" icon={<Icon name="plus" size={13} />}>Add</Button>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: '32px 1.4fr 1fr 1fr 0.5fr 1.2fr 60px',
        padding: '8px 22px',
        borderBottom: `1px solid ${M.line}`,
        background: M.paper2,
        fontFamily: M.mono, fontSize: 9.5, color: M.ink3, fontWeight: 700, letterSpacing: 0.5,
      }}>
        <span></span><span>NAME ↓</span><span>DATES</span><span>BIRTHPLACE</span><span>SEX</span><span>RELATIONSHIPS</span><span></span>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        {rows.map((r, i) => (
          <div key={i} style={{
            display: 'grid',
            gridTemplateColumns: '32px 1.4fr 1fr 1fr 0.5fr 1.2fr 60px',
            padding: '9px 22px',
            borderBottom: `1px solid ${M.line}`,
            alignItems: 'center', fontSize: 12, color: M.ink2,
            background: i === 0 ? M.coralBg : 'transparent',
          }}>
            <Avatar size={26} initials={r.i} tone={r.t} deceased={r.dec} />
            <span style={{ fontFamily: M.serif, fontSize: 13.5, fontWeight: 600, color: M.ink }}>{r.n}</span>
            <span style={{ fontFamily: M.mono, fontSize: 11 }}>{r.d}</span>
            <span style={{ color: M.ink3 }}>{r.p}</span>
            <span style={{ color: M.ink3 }}>{r.g}</span>
            <span style={{ fontSize: 11, color: M.ink3 }}>{r.rel}</span>
            <span style={{ display: 'flex', justifyContent: 'flex-end', gap: 6 }}>
              <Icon name="more" size={13} color={M.ink4} />
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Empty state (new tree) ───────────────────────────────
function MEmpty() {
  return (
    <div style={{ width: '100%', height: '100%', background: M.paper2, position: 'relative', overflow: 'hidden', fontFamily: M.ui }}>
      <div style={{ position: 'absolute', inset: 0, backgroundImage: M.dotGrid, opacity: 0.6 }} />
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 18, padding: 40,
      }}>
        <div style={{
          width: 78, height: 78, borderRadius: '50%',
          border: `1.5px dashed ${M.ink5}`, background: M.paper,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: M.coral,
        }}>
          <Icon name="tree" size={38} />
        </div>
        <div style={{ textAlign: 'center', maxWidth: 380 }}>
          <div style={{ fontFamily: M.serif, fontSize: 24, fontWeight: 600, color: M.ink, letterSpacing: -0.4 }}>
            Start your tree
          </div>
          <div style={{ fontSize: 13, color: M.ink2, marginTop: 6, lineHeight: 1.5 }}>
            Add yourself first, then build outward — parents, siblings, spouse. Or import an existing GEDCOM file from another genealogy app.
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Button variant="primary" icon={<Icon name="plus" size={14} />} size="md">Add yourself</Button>
          <Button icon={<Icon name="download" size={14} />} size="md">Import GEDCOM</Button>
        </div>
        <div style={{ fontSize: 11, color: M.ink4, marginTop: 4 }}>
          Need ideas? <a style={{ color: M.coral, textDecoration: 'underline' }}>Read the starter guide →</a>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  MAddRelationship, MAddMarriage, MIdentifyPhantom,
  MDeleteConfirm, MDeleteRel, MSearch, MPeopleList, MEmpty,
});
