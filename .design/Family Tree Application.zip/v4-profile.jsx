// V4 — Profile variants
// Extends V2Profile with:
//   · V4ProfilePhantom — profile for a phantom/unknown parent, with "Identify"
//     as a primary action (answers the open question from v3: Identify reachable
//     from profile as well as from the tree node).

function V4ProfilePhantom() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      {/* Header — hatched phantom avatar */}
      <div style={{ padding: '14px 16px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 44, height: 44, borderRadius: '50%',
          border: `1.5px dashed ${WF.ink3}`,
          background: 'repeating-linear-gradient(45deg, transparent 0 4px, rgba(0,0,0,0.05) 4px 5px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: WF.ink3, fontWeight: 700, fontSize: 20,
        }}>?</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: WF.ink2, fontStyle: 'italic' }}>
            Unknown parent <Tag style={{ marginLeft: 6 }}>Phantom</Tag>
          </div>
          <div style={{ fontSize: 10, color: WF.ink3 }}>placeholder · shared by 2 siblings</div>
        </div>
        <Btn small>⋯</Btn>
      </div>

      {/* Tabs — disabled except Relationships */}
      <div style={{ display: 'flex', gap: 0, padding: '12px 16px 0', borderBottom: `1.5px solid ${WF.line}` }}>
        {['Overview', 'Relationships', 'Timeline', 'Notes'].map((t, i) => {
          const disabled = i !== 1;
          return (
            <div key={t} style={{
              padding: '6px 10px', fontSize: 11,
              fontWeight: i === 1 ? 700 : 500,
              color: i === 1 ? WF.accent : (disabled ? WF.ink4 : WF.ink2),
              borderBottom: i === 1 ? `2px solid ${WF.accent}` : '2px solid transparent',
              marginBottom: -1.5,
              textDecoration: disabled ? 'line-through' : 'none',
            }}>
              {t}
            </div>
          );
        })}
      </div>

      {/* Primary CTA — Identify (answers the "reachable from profile?" question) */}
      <div style={{ margin: 14, padding: 11, border: `1.5px solid ${WF.accent}`, background: WF.accentBg, borderRadius: 6, display: 'flex', flexDirection: 'column', gap: 7 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 13 }}>✦</span>
          <T size={12} color={WF.accent} weight={700}>Identify this person</T>
        </div>
        <T size={11} color={WF.ink2}>
          This is a placeholder. Resolve it to a real person, create a new named ancestor, or leave it as &ldquo;Unknown.&rdquo;
        </T>
        <div style={{ display: 'flex', gap: 5 }}>
          <Btn small primary>◉ Merge into existing…</Btn>
          <Btn small>＋ Create new</Btn>
        </div>
      </div>

      {/* Known relationships */}
      <div style={{ flex: 1, padding: '0 14px', overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 11 }}>
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <H level={3}>Biological children <Tag style={{ marginLeft: 4 }}>Inferred</Tag></H>
            <T size={10} color={WF.ink3}>2 siblings · linked via this phantom</T>
          </div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            <Chip sub="sibling link · 1988–">Sarah Chen</Chip>
            <Chip sub="sibling link · 1991–">Michael Chen</Chip>
          </div>
        </div>

        <div>
          <H level={3} style={{ marginBottom: 4 }}>Spouse</H>
          <div style={{ padding: '6px 10px', border: `1.5px dashed ${WF.ink4}`, borderRadius: 16, fontSize: 10, color: WF.ink3, maxWidth: 160 }}>
            — not recorded —
          </div>
        </div>

        <div>
          <H level={3} style={{ marginBottom: 4 }}>Notes</H>
          <div style={{ padding: '8px 10px', background: WF.paper2, border: `1px dashed ${WF.ink4}`, borderRadius: 5, fontSize: 11, color: WF.ink3, lineHeight: 1.5 }}>
            Phantom nodes have no editable fields until identified. Sibling
            links <b>persist</b> whether you identify this person, merge it, or
            leave it as Unknown.
          </div>
        </div>
      </div>

      <div style={{ padding: '8px 14px', borderTop: `1.5px solid ${WF.line}`, display: 'flex', gap: 6 }}>
        <Btn small ghost>⌖ Focus in tree</Btn>
        <div style={{ flex: 1 }} />
        <Btn small>Delete phantom</Btn>
      </div>
    </div>
  );
}

Object.assign(window, { V4ProfilePhantom });
