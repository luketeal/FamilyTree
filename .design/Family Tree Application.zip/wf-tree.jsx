// Tree view wireframe variations.
// All share: left search/nav rail, main tree canvas, right profile panel.

const SAMPLE_PEOPLE = [
  { id: 'gp1', name: 'Margaret Chen', years: '1932–2015', gen: 0, x: 0 },
  { id: 'gp2', name: 'Robert Chen', years: '1930–2008', gen: 0, x: 1 },
  { id: 'gp3', name: 'Eva Park', years: '1935–', gen: 0, x: 2 },
  { id: 'gp4', name: 'James Park', years: '1933–2019', gen: 0, x: 3 },
  { id: 'p1', name: 'David Chen', years: '1960–', gen: 1, x: 0 },
  { id: 'p2', name: 'Linda Park', years: '1962–', gen: 1, x: 2 },
  { id: 'p3', name: 'Sarah Chen', years: '1988–', gen: 2, x: 1, focused: true },
  { id: 'p4', name: 'Michael Chen', years: '1991–', gen: 2, x: 2 },
];

// ─────────────────────────────────────────────────────────────
// Shared chrome — top bar, left rail, right panel stub
// ─────────────────────────────────────────────────────────────
function AppTopBar() {
  return (
    <div
      style={{
        height: 44,
        borderBottom: `1.5px solid ${WF.ink}`,
        display: 'flex',
        alignItems: 'center',
        padding: '0 16px',
        gap: 14,
        background: WF.paper,
        flexShrink: 0,
      }}
    >
      <div style={{ fontFamily: WF.hand, fontSize: 22, color: WF.ink, lineHeight: 1 }}>
        The Chen Tree
      </div>
      <div style={{ flex: 1 }} />
      <div
        style={{
          flex: '0 0 320px',
          border: `1.5px solid ${WF.ink3}`,
          borderRadius: 5,
          padding: '6px 10px',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          fontSize: 12,
          color: WF.ink3,
          fontFamily: WF.body,
        }}
      >
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
          <circle cx="11" cy="11" r="7" stroke={WF.ink3} strokeWidth="2" />
          <path d="m20 20-3-3" stroke={WF.ink3} strokeWidth="2" strokeLinecap="round" />
        </svg>
        Search people…
      </div>
      <Btn small>⎌ Undo</Btn>
      <Btn small primary>+ Add Person</Btn>
    </div>
  );
}

function LeftRail() {
  const items = [
    { label: 'Tree', active: true, icon: '⌂' },
    { label: 'People', icon: '☰' },
    { label: 'Pedigree', icon: '↰' },
    { label: 'Descendants', icon: '↳' },
    { label: 'Relate', icon: '↭' },
  ];
  return (
    <div
      style={{
        width: 54,
        borderRight: `1.5px solid ${WF.line}`,
        background: WF.paper2,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '12px 0',
        gap: 4,
        flexShrink: 0,
      }}
    >
      {items.map((it) => (
        <div
          key={it.label}
          style={{
            width: 42,
            padding: '8px 0',
            textAlign: 'center',
            borderRadius: 5,
            background: it.active ? WF.ink : 'transparent',
            color: it.active ? WF.paper : WF.ink2,
            fontFamily: WF.body,
            fontSize: 9,
            fontWeight: 500,
            cursor: 'pointer',
          }}
        >
          <div style={{ fontSize: 16, lineHeight: 1, marginBottom: 3 }}>{it.icon}</div>
          {it.label}
        </div>
      ))}
      <div style={{ flex: 1 }} />
      <div style={{ width: 42, padding: '8px 0', textAlign: 'center', fontFamily: WF.body, fontSize: 9, color: WF.ink2 }}>
        <div style={{ fontSize: 16, lineHeight: 1, marginBottom: 3 }}>⇅</div>
        Im/Ex
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tree node — minimal: name only
// ─────────────────────────────────────────────────────────────
function TreeNode({ person, focused, deceased, small }) {
  const w = small ? 108 : 130;
  const h = small ? 40 : 48;
  return (
    <div
      style={{
        width: w,
        height: h,
        border: `1.5px solid ${focused ? WF.accent : WF.ink}`,
        background: focused ? WF.accentBg : WF.paper,
        borderRadius: 5,
        padding: '6px 10px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        fontFamily: WF.body,
        boxShadow: focused ? `0 2px 0 ${WF.accent}` : 'none',
        position: 'relative',
      }}
    >
      <div style={{ fontSize: small ? 11 : 12, fontWeight: 600, color: WF.ink, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
        {person.name}
      </div>
      <div style={{ fontSize: 10, color: WF.ink3, marginTop: 2 }}>
        {person.years}
      </div>
      {deceased && (
        <div style={{ position: 'absolute', top: 3, right: 5, fontSize: 8, color: WF.ink3 }}>✝</div>
      )}
    </div>
  );
}

// Edge / line drawing helper (SVG overlay)
function Edge({ x1, y1, x2, y2, dashed, accent, thick }) {
  return (
    <line
      x1={x1} y1={y1} x2={x2} y2={y2}
      stroke={accent ? WF.accent : WF.ink}
      strokeWidth={thick ? 2 : 1.5}
      strokeDasharray={dashed ? '4 3' : undefined}
    />
  );
}

// Marriage double-line connector
function MarriageLink({ x1, y1, x2, y2 }) {
  return (
    <>
      <line x1={x1} y1={y1 - 2} x2={x2} y2={y2 - 2} stroke={WF.ink} strokeWidth="1.2" />
      <line x1={x1} y1={y1 + 2} x2={x2} y2={y2 + 2} stroke={WF.ink} strokeWidth="1.2" />
    </>
  );
}

// ─────────────────────────────────────────────────────────────
// Tree A — Classic top-down hierarchy
// ─────────────────────────────────────────────────────────────
function TreeClassic() {
  // Layout: 4 grandparents on top, 2 parent couples, 2 kids
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: WF.dotGrid, overflow: 'hidden' }}>
      {/* Legend */}
      <div style={{ position: 'absolute', top: 12, left: 14, display: 'flex', gap: 14, fontFamily: WF.body, fontSize: 10, color: WF.ink2, zIndex: 2 }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <svg width="22" height="4"><line x1="0" y1="2" x2="22" y2="2" stroke={WF.ink} strokeWidth="1.5" /></svg>
          Biological
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <svg width="22" height="4"><line x1="0" y1="2" x2="22" y2="2" stroke={WF.ink} strokeWidth="1.5" strokeDasharray="3 2" /></svg>
          Adoptive
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <svg width="22" height="8"><line x1="0" y1="2" x2="22" y2="2" stroke={WF.ink} strokeWidth="1" /><line x1="0" y1="6" x2="22" y2="6" stroke={WF.ink} strokeWidth="1" /></svg>
          Marriage
        </span>
      </div>

      {/* Zoom controls */}
      <div style={{ position: 'absolute', bottom: 14, right: 14, display: 'flex', flexDirection: 'column', gap: 4, zIndex: 2 }}>
        <Btn small style={{ width: 28, padding: 4 }}>+</Btn>
        <Btn small style={{ width: 28, padding: 4 }}>−</Btn>
        <Btn small style={{ width: 28, padding: 4, fontSize: 9 }}>⛶</Btn>
      </div>

      {/* SVG lines behind nodes */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {/* Grandparent marriages */}
        <MarriageLink x1={95} y1={80} x2={175} y2={80} />
        <MarriageLink x1={345} y1={80} x2={425} y2={80} />
        {/* Grandparent couples down to parents */}
        <line x1={135} y1={96} x2={135} y2={140} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={385} y1={96} x2={385} y2={140} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={135} y1={140} x2={130} y2={140} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={130} y1={140} x2={130} y2={180} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={385} y1={140} x2={390} y2={140} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={390} y1={140} x2={390} y2={180} stroke={WF.ink} strokeWidth="1.5" />
        {/* Parent marriage */}
        <MarriageLink x1={195} y1={205} x2={325} y2={205} />
        {/* Parents to children */}
        <line x1={260} y1={221} x2={260} y2={265} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={200} y1={265} x2={320} y2={265} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={200} y1={265} x2={200} y2={300} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={320} y1={265} x2={320} y2={300} stroke={WF.ink} strokeWidth="1.5" />
      </svg>

      {/* Nodes */}
      <div style={{ position: 'absolute', left: 30, top: 56 }}><TreeNode small person={SAMPLE_PEOPLE[0]} deceased /></div>
      <div style={{ position: 'absolute', left: 170, top: 56 }}><TreeNode small person={SAMPLE_PEOPLE[1]} deceased /></div>
      <div style={{ position: 'absolute', left: 280, top: 56 }}><TreeNode small person={SAMPLE_PEOPLE[2]} /></div>
      <div style={{ position: 'absolute', left: 420, top: 56 }}><TreeNode small person={SAMPLE_PEOPLE[3]} deceased /></div>

      <div style={{ position: 'absolute', left: 65, top: 180 }}><TreeNode person={SAMPLE_PEOPLE[4]} /></div>
      <div style={{ position: 'absolute', left: 325, top: 180 }}><TreeNode person={SAMPLE_PEOPLE[5]} /></div>

      <div style={{ position: 'absolute', left: 135, top: 300 }}><TreeNode person={SAMPLE_PEOPLE[6]} focused /></div>
      <div style={{ position: 'absolute', left: 255, top: 300 }}><TreeNode person={SAMPLE_PEOPLE[7]} /></div>

      {/* Annotation */}
      <div style={{ position: 'absolute', left: 145, top: 358 }}>
        <ArrowNote direction="left" style={{ transform: 'rotate(-5deg)' }}>focused person</ArrowNote>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tree B — Infinite node-graph canvas
// ─────────────────────────────────────────────────────────────
function TreeCanvas() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: WF.dotGrid, overflow: 'hidden' }}>
      {/* Top toolbar strip */}
      <div style={{ position: 'absolute', top: 10, left: 14, right: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 2 }}>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center', background: WF.paper, border: `1.5px solid ${WF.line}`, borderRadius: 5, padding: '4px 6px', fontFamily: WF.body, fontSize: 10 }}>
          <span style={{ color: WF.ink3 }}>⌂</span>
          <span>David Chen</span>
          <span style={{ color: WF.ink3 }}>›</span>
          <span>Sarah Chen</span>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          <Btn small ghost>Pedigree</Btn>
          <Btn small ghost>Descendants</Btn>
          <Btn small>⛶ Fit</Btn>
        </div>
      </div>

      {/* Scattered node cluster like an infinite canvas — not a strict grid */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {/* Marriage links */}
        <line x1={155} y1={130} x2={175} y2={130} stroke={WF.ink} strokeWidth="1.2" />
        <line x1={155} y1={134} x2={175} y2={134} stroke={WF.ink} strokeWidth="1.2" />
        <line x1={330} y1={110} x2={350} y2={110} stroke={WF.ink} strokeWidth="1.2" />
        <line x1={330} y1={114} x2={350} y2={114} stroke={WF.ink} strokeWidth="1.2" />
        {/* Parent marriage (focused) */}
        <line x1={195} y1={240} x2={215} y2={240} stroke={WF.accent} strokeWidth="1.2" />
        <line x1={195} y1={244} x2={215} y2={244} stroke={WF.accent} strokeWidth="1.2" />

        {/* Lineage curves */}
        <path d="M100 152 Q 120 200, 150 220" stroke={WF.ink} strokeWidth="1.5" fill="none" />
        <path d="M230 152 Q 230 200, 240 220" stroke={WF.ink} strokeWidth="1.5" fill="none" />
        <path d="M290 132 Q 260 200, 240 220" stroke={WF.ink} strokeWidth="1.5" fill="none" />
        <path d="M400 132 Q 380 200, 340 220" stroke={WF.ink} strokeWidth="1.5" fill="none" />

        <path d="M175 265 Q 175 310, 175 340" stroke={WF.accent} strokeWidth="1.5" fill="none" />
        <path d="M235 265 Q 255 310, 290 340" stroke={WF.accent} strokeWidth="1.5" fill="none" />

        {/* Adoptive link (dashed) */}
        <path d="M340 265 Q 330 300, 310 340" stroke={WF.ink} strokeWidth="1.5" fill="none" strokeDasharray="4 3" />
      </svg>

      {/* Nodes scattered */}
      <div style={{ position: 'absolute', left: 40, top: 110 }}><TreeNode small person={{ name: 'Margaret C.', years: '1932–2015' }} deceased /></div>
      <div style={{ position: 'absolute', left: 180, top: 110 }}><TreeNode small person={{ name: 'Robert C.', years: '1930–2008' }} deceased /></div>
      <div style={{ position: 'absolute', left: 240, top: 90 }}><TreeNode small person={{ name: 'Eva Park', years: '1935–' }} /></div>
      <div style={{ position: 'absolute', left: 355, top: 90 }}><TreeNode small person={{ name: 'James Park', years: '1933–2019' }} deceased /></div>

      <div style={{ position: 'absolute', left: 90, top: 220 }}><TreeNode person={{ name: 'David Chen', years: '1960–' }} /></div>
      <div style={{ position: 'absolute', left: 225, top: 220 }}><TreeNode person={{ name: 'Linda Park', years: '1962–' }} /></div>

      <div style={{ position: 'absolute', left: 115, top: 340 }}><TreeNode person={{ name: 'Sarah Chen', years: '1988–' }} focused /></div>
      <div style={{ position: 'absolute', left: 255, top: 340 }}><TreeNode person={{ name: 'Michael', years: '1991–' }} /></div>

      {/* Extra — adopted cousin */}
      <div style={{ position: 'absolute', left: 370, top: 300 }}>
        <TreeNode small person={{ name: 'Aunt Rose', years: '1965–' }} />
      </div>

      {/* Mini-map */}
      <div style={{ position: 'absolute', bottom: 14, right: 14, width: 120, height: 80, border: `1.5px solid ${WF.line}`, background: WF.paper, borderRadius: 4, zIndex: 2 }}>
        <div style={{ fontFamily: WF.body, fontSize: 9, color: WF.ink3, padding: '3px 6px', borderBottom: `1px solid ${WF.line}` }}>MINIMAP</div>
        <div style={{ position: 'relative', padding: 6 }}>
          {[...Array(8)].map((_, i) => (
            <div key={i} style={{ position: 'absolute', left: 10 + (i % 4) * 22, top: 6 + Math.floor(i / 4) * 22, width: 10, height: 6, background: i === 4 ? WF.accent : WF.ink3, borderRadius: 1 }} />
          ))}
          <div style={{ position: 'absolute', left: 8, top: 4, width: 44, height: 30, border: `1.5px solid ${WF.accent}`, borderRadius: 2 }} />
        </div>
      </div>

      {/* Annotation */}
      <div style={{ position: 'absolute', left: 220, top: 395, zIndex: 2 }}>
        <Annotation>highlighted lineage to focused person</Annotation>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tree C — Hybrid: ancestors up, descendants down, sideways siblings
// ─────────────────────────────────────────────────────────────
function TreeHybrid() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: WF.dotGrid, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 12, left: 14, fontFamily: WF.body, fontSize: 10, color: WF.ink2, textTransform: 'uppercase', letterSpacing: 0.8 }}>
        ↑ Ancestors
      </div>
      <div style={{ position: 'absolute', bottom: 12, left: 14, fontFamily: WF.body, fontSize: 10, color: WF.ink2, textTransform: 'uppercase', letterSpacing: 0.8 }}>
        ↓ Descendants
      </div>
      <div style={{ position: 'absolute', top: '47%', right: 14, fontFamily: WF.body, fontSize: 10, color: WF.ink2, textTransform: 'uppercase', letterSpacing: 0.8 }}>
        Siblings →
      </div>

      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {/* G-parents to parents */}
        <line x1={120} y1={75} x2={120} y2={120} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={120} y1={120} x2={175} y2={120} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={175} y1={120} x2={175} y2={165} stroke={WF.ink} strokeWidth="1.5" />

        <line x1={345} y1={75} x2={345} y2={120} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={345} y1={120} x2={300} y2={120} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={300} y1={120} x2={300} y2={165} stroke={WF.ink} strokeWidth="1.5" />

        {/* parent marriage */}
        <line x1={195} y1={188} x2={275} y2={188} stroke={WF.ink} strokeWidth="1" />
        <line x1={195} y1={192} x2={275} y2={192} stroke={WF.ink} strokeWidth="1" />

        {/* parents to focused */}
        <line x1={235} y1={213} x2={235} y2={250} stroke={WF.accent} strokeWidth="1.5" />

        {/* siblings (horizontal bracket) */}
        <line x1={235} y1={275} x2={400} y2={275} stroke={WF.ink} strokeWidth="1.5" strokeDasharray="2 2" />
        <line x1={400} y1={275} x2={400} y2={285} stroke={WF.ink} strokeWidth="1.5" strokeDasharray="2 2" />

        {/* focused to children */}
        <line x1={195} y1={287} x2={275} y2={287} stroke={WF.ink} strokeWidth="1" />
        <line x1={195} y1={291} x2={275} y2={291} stroke={WF.ink} strokeWidth="1" />
        <line x1={235} y1={312} x2={235} y2={345} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={185} y1={345} x2={285} y2={345} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={185} y1={345} x2={185} y2={378} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={285} y1={345} x2={285} y2={378} stroke={WF.ink} strokeWidth="1.5" />
      </svg>

      <div style={{ position: 'absolute', left: 55, top: 35 }}><TreeNode small person={{ name: 'Margaret', years: "'32–'15" }} deceased /></div>
      <div style={{ position: 'absolute', left: 280, top: 35 }}><TreeNode small person={{ name: 'Eva Park', years: "'35–" }} /></div>

      <div style={{ position: 'absolute', left: 110, top: 165 }}><TreeNode small person={{ name: 'David Chen', years: '1960–' }} /></div>
      <div style={{ position: 'absolute', left: 240, top: 165 }}><TreeNode small person={{ name: 'Linda Park', years: '1962–' }} /></div>

      <div style={{ position: 'absolute', left: 175, top: 250 }}><TreeNode person={{ name: 'Sarah Chen', years: '1988–' }} focused /></div>

      {/* Spouse */}
      <div style={{ position: 'absolute', left: 340, top: 255 }}><TreeNode small person={{ name: 'Alex Tan', years: "'87–" }} /></div>

      {/* Sibling */}
      <div style={{ position: 'absolute', left: 360, top: 285 }}>
        <div style={{ fontFamily: WF.body, fontSize: 10, color: WF.ink3, marginBottom: 3 }}>sibling</div>
      </div>

      <div style={{ position: 'absolute', left: 120, top: 378 }}><TreeNode small person={{ name: 'Liam', years: '2018–' }} /></div>
      <div style={{ position: 'absolute', left: 240, top: 378 }}><TreeNode small person={{ name: 'Mia', years: '2020–' }} /></div>

      {/* Up/Down jump buttons */}
      <div style={{ position: 'absolute', left: 215, top: 430, display: 'flex', gap: 6 }}>
        <Btn small ghost>↑ Up a generation</Btn>
        <Btn small ghost>↓ Down a generation</Btn>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tree D — Collapsible outline / indented list
// ─────────────────────────────────────────────────────────────
function TreeOutline() {
  const Row = ({ depth = 0, expanded = true, chevron = true, name, years, tag, focused, dashed }) => (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '6px 8px',
        paddingLeft: 12 + depth * 22,
        borderLeft: dashed ? `1.5px dashed ${WF.ink3}` : `1.5px solid ${WF.line2}`,
        borderRadius: 4,
        background: focused ? WF.accentBg : 'transparent',
        fontFamily: WF.body,
        fontSize: 12,
        cursor: 'pointer',
      }}
    >
      {chevron ? (
        <span style={{ color: WF.ink3, fontSize: 9, width: 8 }}>{expanded ? '▾' : '▸'}</span>
      ) : (
        <span style={{ width: 8 }} />
      )}
      <Avatar size={22} />
      <span style={{ fontWeight: 600, color: focused ? WF.accent : WF.ink }}>{name}</span>
      <span style={{ color: WF.ink3, fontSize: 11 }}>{years}</span>
      {tag && <Tag>{tag}</Tag>}
    </div>
  );

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: WF.paper, overflow: 'hidden' }}>
      <div style={{ padding: '12px 14px', borderBottom: `1.5px solid ${WF.line}`, display: 'flex', alignItems: 'center', gap: 10, fontFamily: WF.body, fontSize: 11, color: WF.ink2 }}>
        <Btn small ghost>⇉ Expand all</Btn>
        <Btn small ghost>⇇ Collapse all</Btn>
        <div style={{ flex: 1 }} />
        <T size={11} color={WF.ink3}>8 people · 3 generations</T>
      </div>

      <div style={{ padding: 10, display: 'flex', flexDirection: 'column', gap: 2 }}>
        <Row name="Margaret Chen" years="1932–2015" tag="♀" />
        <div style={{ paddingLeft: 22 }}>
          <Row depth={1} name="Robert Chen" years="1930–2008" tag="m. 1955" />
        </div>
        <Row depth={1} name="David Chen" years="1960–" />
        <Row depth={2} name="↳ m. Linda Park" years="1962–" tag="spouse" />
        <Row depth={2} name="Sarah Chen" years="1988–" focused />
        <Row depth={3} name="Liam Chen-Tan" years="2018–" />
        <Row depth={3} name="Mia Chen-Tan" years="2020–" />
        <Row depth={2} name="Michael Chen" years="1991–" />
        <Row depth={3} dashed name="Emma Chen" years="2015–" tag="adoptive" />
      </div>

      <div style={{ position: 'absolute', bottom: 14, left: 14, right: 14, padding: '8px 12px', border: `1.5px dashed ${WF.ink3}`, borderRadius: 5, fontFamily: WF.body, fontSize: 11, color: WF.ink2, background: WF.paper2 }}>
        ⚠ Dashed border = adoptive relationship · indent = generation
      </div>
    </div>
  );
}

Object.assign(window, { AppTopBar, LeftRail, TreeNode, TreeClassic, TreeCanvas, TreeHybrid, TreeOutline });
