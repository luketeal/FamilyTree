// Mid-fi tokens — quiet warm-neutral palette + Inter/Source Serif/JetBrains Mono.
// Single coral accent. Secondary muted teal for adoptive relationships.

const M = {
  // Paper / ink
  paper:    '#fbfaf7',
  paper2:   '#f3f0e9',
  paper3:   '#ece8de',
  ink:      '#1c1a17',
  ink2:     '#3a362f',
  ink3:     '#6f6a5e',
  ink4:     '#9a9387',
  ink5:     '#c4beb1',
  line:     '#e3ddce',
  line2:    '#d8d2c4',
  hairline: '#eee9dc',

  // Accents
  coral:     '#c96442',
  coralBg:   '#fbeee7',
  coralHov:  '#b25232',
  coralLine: '#e8b8a3',

  // Adoptive (secondary, dashed everywhere)
  teal:     '#3f7d6e',
  tealBg:   '#e6efeb',
  tealLine: '#a8c8be',

  // Step (dotted neutral)
  step:     '#8a8377',

  // States
  ok:      '#3a7a5a',
  okBg:    '#e6f0ea',
  warn:    '#a86b1a',
  warnBg:  '#f6ecda',
  err:     '#a8412a',
  errBg:   '#f6e3da',

  // Type
  ui:      '"Inter", system-ui, -apple-system, sans-serif',
  serif:   '"Source Serif 4", "Source Serif Pro", Georgia, serif',
  mono:    '"JetBrains Mono", ui-monospace, "SF Mono", monospace',

  // Effects
  cardShadow: '0 1px 2px rgba(28,26,23,0.04), 0 4px 16px rgba(28,26,23,0.05)',
  popShadow:  '0 4px 12px rgba(28,26,23,0.08), 0 16px 48px rgba(28,26,23,0.12)',
  dotGrid:    'radial-gradient(circle, #e3ddce 1px, transparent 1px) 0 0 / 18px 18px',
};

// ─── Button ───────────────────────────────────────────────
function Button({ children, variant = 'secondary', size = 'md', icon, iconRight, full, disabled, style = {}, ...rest }) {
  const sizes = {
    sm: { pad: '5px 10px', fs: 12, h: 26, gap: 5 },
    md: { pad: '7px 14px', fs: 13, h: 32, gap: 6 },
    lg: { pad: '9px 18px', fs: 14, h: 38, gap: 7 },
  };
  const s = sizes[size];
  const styles = {
    primary:    { bg: M.coral, fg: '#fff', bd: M.coral, hbg: M.coralHov },
    secondary:  { bg: M.paper, fg: M.ink, bd: M.line2, hbg: M.paper2 },
    ghost:      { bg: 'transparent', fg: M.ink2, bd: 'transparent', hbg: M.paper2 },
    destructive:{ bg: M.paper, fg: M.err, bd: M.coralLine, hbg: M.errBg },
    teal:       { bg: M.teal, fg: '#fff', bd: M.teal, hbg: '#33665a' },
  }[variant];
  return (
    <button
      {...rest}
      disabled={disabled}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: s.gap,
        padding: s.pad, fontSize: s.fs, height: s.h,
        fontFamily: M.ui, fontWeight: 500, letterSpacing: -0.05,
        background: styles.bg, color: styles.fg,
        border: `1px solid ${styles.bd}`,
        borderRadius: 6,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        width: full ? '100%' : 'auto',
        whiteSpace: 'nowrap',
        transition: 'background 0.12s, border-color 0.12s',
        ...style,
      }}
      onMouseEnter={(e) => !disabled && (e.currentTarget.style.background = styles.hbg)}
      onMouseLeave={(e) => !disabled && (e.currentTarget.style.background = styles.bg)}
    >
      {icon && <span style={{ display: 'inline-flex', alignItems: 'center' }}>{icon}</span>}
      {children}
      {iconRight && <span style={{ display: 'inline-flex', alignItems: 'center', opacity: 0.7 }}>{iconRight}</span>}
    </button>
  );
}

// ─── Icon (24-grid line icons) ────────────────────────────
function Icon({ name, size = 16, color, style = {} }) {
  const ic = {
    plus:    <path d="M12 5v14M5 12h14"/>,
    minus:   <path d="M5 12h14"/>,
    close:   <path d="M5 5l14 14M19 5L5 19"/>,
    check:   <path d="M5 12l5 5L20 7"/>,
    chev_d:  <path d="M6 9l6 6 6-6"/>,
    chev_r:  <path d="M9 6l6 6-6 6"/>,
    chev_l:  <path d="M15 6l-6 6 6 6"/>,
    chev_u:  <path d="M6 15l6-6 6 6"/>,
    search:  <><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></>,
    user:    <><circle cx="12" cy="9" r="3.5"/><path d="M5 20c1-4 4-6 7-6s6 2 7 6"/></>,
    users:   <><circle cx="9" cy="9" r="3"/><path d="M3 19c0-3 3-5 6-5s6 2 6 5"/><path d="M16 6.5a3 3 0 0 1 0 5"/><path d="M21 18.5c0-2-1.5-3.5-4-4"/></>,
    tree:    <><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/><circle cx="12" cy="6" r="2"/><path d="M12 8v3a3 3 0 0 1-3 3H6v2M12 8v3a3 3 0 0 0 3 3h3v2"/></>,
    grid:    <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    list:    <><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="0.8" fill="currentColor"/><circle cx="4" cy="12" r="0.8" fill="currentColor"/><circle cx="4" cy="18" r="0.8" fill="currentColor"/></>,
    link:    <><path d="M10 14a4 4 0 0 0 5.6 0l3-3a4 4 0 0 0-5.6-5.6l-1 1"/><path d="M14 10a4 4 0 0 0-5.6 0l-3 3a4 4 0 0 0 5.6 5.6l1-1"/></>,
    edit:    <><path d="M4 20h4l11-11-4-4L4 16v4z"/><path d="M14 5l4 4"/></>,
    trash:   <><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></>,
    undo:    <><path d="M9 14l-4-4 4-4"/><path d="M5 10h9a5 5 0 0 1 5 5v0a5 5 0 0 1-5 5h-3"/></>,
    download:<><path d="M12 4v12M7 11l5 5 5-5"/><path d="M5 20h14"/></>,
    upload:  <><path d="M12 20V8M7 13l5-5 5 5"/><path d="M5 4h14"/></>,
    print:   <><path d="M7 9V4h10v5"/><rect x="4" y="9" width="16" height="8" rx="1"/><path d="M7 17v3h10v-3"/></>,
    fit:     <><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></>,
    focus:   <><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/></>,
    more:    <><circle cx="5" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="19" cy="12" r="1.4" fill="currentColor"/></>,
    info:    <><circle cx="12" cy="12" r="9"/><path d="M12 8v0M12 11v6"/></>,
    warn:    <><path d="M12 4l9 16H3L12 4z"/><path d="M12 10v4M12 17v0"/></>,
    heart:   <path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/>,
    home:    <><path d="M4 11l8-7 8 7v9h-5v-6h-6v6H4z"/></>,
    eye:     <><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></>,
    drag:    <><circle cx="9" cy="6" r="1" fill="currentColor"/><circle cx="15" cy="6" r="1" fill="currentColor"/><circle cx="9" cy="12" r="1" fill="currentColor"/><circle cx="15" cy="12" r="1" fill="currentColor"/><circle cx="9" cy="18" r="1" fill="currentColor"/><circle cx="15" cy="18" r="1" fill="currentColor"/></>,
    settings:<><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2"/></>,
    filter:  <path d="M4 5h16l-6 8v6l-4-2v-4L4 5z"/>,
    photo:   <><rect x="3" y="5" width="18" height="14" rx="1"/><circle cx="8.5" cy="10" r="1.5"/><path d="M21 17l-5-5-9 7"/></>,
    crop:    <><path d="M6 2v16h16M22 18H6M22 18V6"/><path d="M2 6h16"/></>,
    sparkle: <path d="M12 4l1.5 4.5L18 10l-4.5 1.5L12 16l-1.5-4.5L6 10l4.5-1.5z"/>,
    cake:    <><path d="M5 11h14v9H5z"/><path d="M5 14c2 0 2 2 4 2s2-2 4-2 2 2 4 2 2-2 4-2"/><path d="M9 5v3M12 4v4M15 5v3"/></>,
    cross_d: <><path d="M12 5v6M9 8h6"/></>, // small cross — deceased
    ring:    <><circle cx="12" cy="14" r="5"/><path d="M9 4h6l-2 4h-2z"/></>,
    map:     <path d="M9 3 3 5v16l6-2 6 2 6-2V3l-6 2-6-2zm0 0v16m6-14v16"/>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color || 'currentColor'} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"
      style={{ flexShrink: 0, ...style }}>
      {ic[name] || null}
    </svg>
  );
}

// ─── Field / Input / Select / DateField ───────────────────
function Field({ label, hint, error, required, children, style = {} }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 5, ...style }}>
      {label && (
        <label style={{ fontFamily: M.ui, fontSize: 11, fontWeight: 600, color: M.ink2, letterSpacing: 0.1 }}>
          {label}{required && <span style={{ color: M.coral, marginLeft: 2 }}>*</span>}
        </label>
      )}
      {children}
      {(hint || error) && (
        <span style={{ fontFamily: M.ui, fontSize: 11, color: error ? M.err : M.ink3 }}>{error || hint}</span>
      )}
    </div>
  );
}

function Input({ value, placeholder, icon, w, error, readOnly, style = {}, ...rest }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 6,
      border: `1px solid ${error ? M.err : M.line2}`,
      background: M.paper, borderRadius: 6,
      padding: '0 10px', height: 34,
      width: w || '100%',
      transition: 'border-color 0.12s, box-shadow 0.12s',
      ...style,
    }}>
      {icon && <Icon name={icon} size={14} color={M.ink3} />}
      <input readOnly value={value} placeholder={placeholder} {...rest}
        onChange={() => {}}
        style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent',
          fontFamily: M.ui, fontSize: 13, color: M.ink, minWidth: 0 }} />
    </div>
  );
}

function Select({ value, w, style = {} }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 6,
      border: `1px solid ${M.line2}`, background: M.paper, borderRadius: 6,
      padding: '0 10px', height: 34, width: w || '100%',
      fontFamily: M.ui, fontSize: 13, color: M.ink, cursor: 'pointer',
      ...style,
    }}>
      <span>{value}</span>
      <Icon name="chev_d" size={14} color={M.ink3} />
    </div>
  );
}

function Textarea({ value, placeholder, rows = 4, count }) {
  return (
    <div style={{ position: 'relative' }}>
      <div style={{
        border: `1px solid ${M.line2}`, background: M.paper, borderRadius: 6,
        padding: '8px 10px', fontFamily: M.ui, fontSize: 13, color: value ? M.ink : M.ink4,
        minHeight: rows * 18 + 16, lineHeight: 1.55, whiteSpace: 'pre-wrap',
      }}>
        {value || placeholder}
      </div>
      {count !== undefined && (
        <div style={{ position: 'absolute', bottom: 6, right: 8, fontFamily: M.mono, fontSize: 10, color: M.ink4 }}>
          {count} / 5,000
        </div>
      )}
    </div>
  );
}

// ─── Tag / Badge ───────────────────────────────────────────
function Tag({ children, tone = 'neutral', icon, style = {} }) {
  const tones = {
    neutral: { bg: M.paper2, fg: M.ink2, bd: M.line },
    accent:  { bg: M.coralBg, fg: M.coral, bd: M.coralLine },
    teal:    { bg: M.tealBg, fg: M.teal, bd: M.tealLine },
    warn:    { bg: M.warnBg, fg: M.warn, bd: '#e8c896' },
    ok:      { bg: M.okBg, fg: M.ok, bd: '#bbd6c5' },
    ghost:   { bg: 'transparent', fg: M.ink3, bd: M.line },
  }[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 7px', fontSize: 10.5, fontFamily: M.ui, fontWeight: 600,
      background: tones.bg, color: tones.fg, border: `1px solid ${tones.bd}`,
      borderRadius: 4, letterSpacing: 0.3, textTransform: 'uppercase',
      lineHeight: 1.4,
      ...style,
    }}>
      {icon && <Icon name={icon} size={10} />}
      {children}
    </span>
  );
}

// ─── Avatar (photo placeholder) ────────────────────────────
function Avatar({ size = 36, initials, tone = 'neutral', sex, deceased, style = {}, photo }) {
  const tones = {
    neutral: ['#e8e2d3', '#5a544a'],
    coral:   [M.coralBg, M.coral],
    teal:    [M.tealBg, M.teal],
    blue:    ['#dde6ee', '#3a5d7a'],
    rose:    ['#f0dfe2', '#86445a'],
    sage:    ['#dfe8d8', '#506b3a'],
    sand:    ['#ece2cd', '#7a624a'],
  };
  const palette = tones[tone] || tones.neutral;
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: photo ? palette[0] : palette[0],
      backgroundImage: photo ? `repeating-linear-gradient(45deg, transparent 0 4px, rgba(0,0,0,0.04) 4px 5px)` : 'none',
      border: `1px solid ${M.line2}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: M.ui, fontSize: size * 0.36, fontWeight: 600,
      color: palette[1], flexShrink: 0, position: 'relative',
      letterSpacing: -0.3,
      ...style,
    }}>
      {initials || (
        <Icon name="user" size={size * 0.5} color={palette[1]} />
      )}
      {deceased && (
        <div style={{
          position: 'absolute', bottom: -2, right: -2,
          width: size * 0.36, height: size * 0.36, borderRadius: '50%',
          background: M.paper, border: `1px solid ${M.line2}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: M.serif, fontSize: size * 0.22, fontWeight: 600, color: M.ink3,
        }}>†</div>
      )}
    </div>
  );
}

// ─── Tab strip ─────────────────────────────────────────────
function Tabs({ items, active, style = {} }) {
  return (
    <div style={{ display: 'flex', gap: 0, borderBottom: `1px solid ${M.line}`, ...style }}>
      {items.map((t) => {
        const a = t === active || t.label === active;
        const label = typeof t === 'string' ? t : t.label;
        const dis = typeof t === 'object' && t.disabled;
        return (
          <div key={label} style={{
            padding: '10px 14px', fontSize: 12.5, fontWeight: a ? 600 : 500,
            fontFamily: M.ui,
            color: dis ? M.ink4 : a ? M.ink : M.ink3,
            borderBottom: a ? `2px solid ${M.coral}` : '2px solid transparent',
            marginBottom: -1, cursor: dis ? 'not-allowed' : 'pointer',
            display: 'flex', alignItems: 'center', gap: 5,
          }}>
            {label}
            {typeof t === 'object' && t.count !== undefined &&
              <span style={{ fontSize: 10, color: M.ink4, fontFamily: M.mono }}>{t.count}</span>}
          </div>
        );
      })}
    </div>
  );
}

// ─── Section header (within a panel) ───────────────────────
function SectionHead({ title, count, action, style = {} }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
      marginBottom: 8, ...style,
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 7 }}>
        <span style={{ fontFamily: M.ui, fontSize: 11, fontWeight: 700, color: M.ink2, textTransform: 'uppercase', letterSpacing: 0.6 }}>
          {title}
        </span>
        {count !== undefined && (
          <span style={{ fontFamily: M.mono, fontSize: 10, color: M.ink4 }}>{count}</span>
        )}
      </div>
      {action}
    </div>
  );
}

// ─── Relation chip (person reference) ──────────────────────
function PersonChip({ name, sub, kind = 'bio', tone = 'neutral', initials, deceased, action, style = {} }) {
  // kind: 'bio' (solid), 'adoptive' (dashed teal), 'step' (dotted), 'phantom' (dashed gray hatch)
  const styles = {
    bio:      { bd: `1px solid ${M.line}`, bg: M.paper },
    adoptive: { bd: `1px dashed ${M.tealLine}`, bg: M.tealBg },
    step:     { bd: `1px dotted ${M.ink5}`, bg: M.paper2 },
    phantom:  { bd: `1px dashed ${M.ink5}`, bg: 'repeating-linear-gradient(45deg, transparent 0 5px, rgba(0,0,0,0.025) 5px 6px)' },
    spouse:   { bd: `1px solid ${M.line}`, bg: M.paper },
  }[kind];
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '4px 10px 4px 4px',
      borderRadius: 999,
      ...styles,
      fontFamily: M.ui,
      ...style,
    }}>
      <Avatar size={24} initials={initials} tone={tone} deceased={deceased} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0, lineHeight: 1.2 }}>
        <span style={{ fontSize: 12.5, fontWeight: 600, color: M.ink }}>{name}</span>
        {sub && <span style={{ fontSize: 10.5, color: M.ink3, fontFamily: M.mono }}>{sub}</span>}
      </div>
      {action}
    </div>
  );
}

// ─── Card / Panel shells ───────────────────────────────────
function Card({ children, style = {}, padded = true, ...rest }) {
  return (
    <div {...rest} style={{
      background: M.paper, border: `1px solid ${M.line}`, borderRadius: 8,
      padding: padded ? 16 : 0, fontFamily: M.ui,
      ...style,
    }}>{children}</div>
  );
}

function Dialog({ title, sub, children, footer, w = 480, style = {} }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      background: 'rgba(28,26,23,0.32)',
      backdropFilter: 'blur(2px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 20, fontFamily: M.ui, overflow: 'hidden',
    }}>
      <div style={{
        width: '100%', maxWidth: w,
        background: M.paper,
        border: `1px solid ${M.line2}`, borderRadius: 10,
        boxShadow: M.popShadow,
        display: 'flex', flexDirection: 'column',
        maxHeight: '100%',
        ...style,
      }}>
        <div style={{ padding: '16px 20px 12px', borderBottom: `1px solid ${M.hairline}` }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
            <div>
              <div style={{ fontFamily: M.serif, fontSize: 18, fontWeight: 600, color: M.ink, letterSpacing: -0.2 }}>{title}</div>
              {sub && <div style={{ fontSize: 12, color: M.ink3, marginTop: 3 }}>{sub}</div>}
            </div>
            <div style={{ width: 28, height: 28, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: M.ink3 }}>
              <Icon name="close" size={14} />
            </div>
          </div>
        </div>
        <div style={{ padding: '14px 20px', overflow: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: 14 }}>
          {children}
        </div>
        {footer && (
          <div style={{ padding: '12px 20px', borderTop: `1px solid ${M.hairline}`, background: M.paper2, borderRadius: '0 0 10px 10px',
            display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 8 }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Segmented control ────────────────────────────────────
function Segmented({ items, active, full, style = {} }) {
  return (
    <div style={{
      display: 'inline-flex', background: M.paper2, border: `1px solid ${M.line2}`, borderRadius: 7, padding: 2, gap: 0,
      width: full ? '100%' : 'auto',
      ...style,
    }}>
      {items.map((it) => {
        const label = typeof it === 'string' ? it : it.label;
        const a = label === active;
        return (
          <div key={label} style={{
            flex: full ? 1 : 'unset',
            padding: '6px 12px', fontSize: 12, fontWeight: a ? 600 : 500,
            color: a ? M.ink : M.ink3, fontFamily: M.ui,
            background: a ? M.paper : 'transparent',
            border: a ? `1px solid ${M.line2}` : '1px solid transparent',
            borderRadius: 5, cursor: 'pointer', textAlign: 'center',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
            boxShadow: a ? '0 1px 2px rgba(28,26,23,0.05)' : 'none',
            transition: 'background 0.12s',
          }}>
            {typeof it === 'object' && it.icon && <Icon name={it.icon} size={12} />}
            {label}
          </div>
        );
      })}
    </div>
  );
}

// ─── Toast / Inline alert ─────────────────────────────────
function Alert({ tone = 'info', title, children, icon, style = {} }) {
  const tones = {
    info: { bg: M.paper2, fg: M.ink2, bd: M.line, ic: M.ink3 },
    warn: { bg: M.warnBg, fg: '#6a4c12', bd: '#e8c896', ic: M.warn },
    err:  { bg: M.errBg, fg: '#7a2f1d', bd: M.coralLine, ic: M.err },
    danger:{ bg: M.errBg, fg: '#7a2f1d', bd: M.coralLine, ic: M.err },
    ok:   { bg: M.okBg, fg: '#23553f', bd: '#bbd6c5', ic: M.ok },
    coral:{ bg: M.coralBg, fg: '#7a2f1d', bd: M.coralLine, ic: M.coral },
  }[tone];
  return (
    <div style={{
      display: 'flex', gap: 10, padding: '10px 12px',
      background: tones.bg, border: `1px solid ${tones.bd}`, borderRadius: 7,
      fontFamily: M.ui, fontSize: 12, color: tones.fg, lineHeight: 1.5,
      ...style,
    }}>
      {icon && <Icon name={icon} size={16} color={tones.ic} style={{ flexShrink: 0, marginTop: 1 }} />}
      <div style={{ flex: 1 }}>
        {title && <div style={{ fontWeight: 600, marginBottom: 2 }}>{title}</div>}
        {children}
      </div>
    </div>
  );
}

Object.assign(window, {
  M, Button, Icon, Field, Input, Select, Textarea,
  Tag, Avatar, Tabs, SectionHead, PersonChip,
  Card, Dialog, Segmented, Alert,
});
