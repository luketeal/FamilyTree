// Forms, dialogs, people list, empty state

// ─── Add Person form A — single-column ─────────────
function AddPersonA() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, padding: 18, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div>
        <H level={1}>Add a person</H>
        <T size={11} color={WF.ink3}>Only name is required. Everything else is optional.</T>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <Input label="First name" required placeholder="Sarah" />
        <Input label="Last name" required placeholder="Chen" />
        <Input label="Birth surname" placeholder="optional" />
        <Input label="Gender" value="Female ▾" />
        <Input label="Birth date" placeholder="YYYY-MM-DD" />
        <Input label="Birth place" placeholder="City, State" />
        <Input label="Death date" placeholder="optional" />
        <Input label="Death place" placeholder="optional" />
      </div>
      <div>
        <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Photo</T>
        <Placeholder h={60} label="drop photo · 5mb max" style={{ marginTop: 4 }} />
      </div>
      <div>
        <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Notes</T>
        <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 4, padding: 8, marginTop: 4, minHeight: 50 }}>
          <Lines count={2} h={6} />
        </div>
        <T size={10} color={WF.ink3} style={{ float: 'right' }}>0 / 5000</T>
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', borderTop: `1px solid ${WF.line}`, paddingTop: 10 }}>
        <Btn small>Cancel</Btn>
        <Btn small primary>Save person</Btn>
      </div>
    </div>
  );
}

// B — Progressive / conversational
function AddPersonB() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, padding: 20, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div>
        <T size={10} color={WF.ink3} weight={600}>STEP 1 of 3 · BASICS</T>
        <div style={{ display: 'flex', gap: 3, marginTop: 4 }}>
          <div style={{ height: 3, flex: 1, background: WF.accent }} />
          <div style={{ height: 3, flex: 1, background: WF.line }} />
          <div style={{ height: 3, flex: 1, background: WF.line }} />
        </div>
      </div>
      <div style={{ fontFamily: WF.hand, fontSize: 26, lineHeight: 1.2, color: WF.ink }}>
        Who are we adding?
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <Input label="First name" required placeholder="Sarah" />
        <Input label="Last name" required placeholder="Chen" />
      </div>
      <Input label="Also known as / birth surname" placeholder="optional — née ___" />
      <div style={{ display: 'flex', gap: 8 }}>
        <Input label="Birth year" placeholder="1988" />
        <Input label="Gender" value="— pick —" />
      </div>
      <div style={{ padding: 10, background: WF.accentBg, border: `1.5px dashed ${WF.accent}`, borderRadius: 5 }}>
        <T size={11} color={WF.accent} weight={600}>⚠ A "Sarah Chen" born 1988 already exists.</T>
        <div style={{ marginTop: 4 }}><T size={11}>View existing · Continue anyway</T></div>
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <Btn small ghost>← Cancel</Btn>
        <Btn small primary>Continue →</Btn>
      </div>
    </div>
  );
}

// C — Quick add inline popover
function AddPersonC() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper2, padding: 20, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
      <div style={{ width: 280, padding: 16, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 8, boxShadow: '3px 3px 0 rgba(0,0,0,0.08)', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <H level={2}>Quick add</H>
          <T size={14} color={WF.ink3}>✕</T>
        </div>
        <Input label="Full name" required placeholder="Sarah Chen" />
        <div style={{ display: 'flex', gap: 6 }}>
          <Input label="Born" placeholder="YYYY" small />
          <Input label="Died" placeholder="—" small />
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          {['♀', '♂', '⚥', '?'].map((g, i) => (
            <div key={i} style={{ flex: 1, padding: '6px 0', textAlign: 'center', border: `1.5px solid ${i === 0 ? WF.accent : WF.ink3}`, background: i === 0 ? WF.accentBg : WF.paper, borderRadius: 4, fontSize: 13, color: i === 0 ? WF.accent : WF.ink }}>
              {g}
            </div>
          ))}
        </div>
        <Btn small primary>Add & open profile</Btn>
        <div style={{ textAlign: 'center' }}>
          <T size={10} color={WF.ink3}>or <span style={{ color: WF.accent, textDecoration: 'underline' }}>use full form →</span></T>
        </div>
      </div>
      <ArrowNote direction="left" style={{ transform: 'rotate(-3deg)' }}>opens over tree — fast common case</ArrowNote>
    </div>
  );
}

// ─── Relationship dialog A — search-and-select ──────
function RelDialogA() {
  return (
    <div style={{ width: '100%', height: '100%', background: 'rgba(0,0,0,0.08)', padding: 16, fontFamily: WF.body, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      <div style={{ width: '100%', maxWidth: 340, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 8, boxShadow: '4px 4px 0 rgba(0,0,0,0.1)', padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <H level={2}>Add biological parent</H>
        <T size={11} color={WF.ink3}>for Sarah Chen</T>
        <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '8px 10px', fontSize: 12, color: WF.ink3 }}>🔍  Search by name…</div>
        <T size={10} color={WF.ink3} weight={600} style={{ textTransform: 'uppercase' }}>Matches</T>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {['David Chen · 1960–', 'Daniel Chen · 1975–', 'Diana Chen · 1982–'].map((n, i) => (
            <div key={n} style={{ padding: '6px 8px', border: `1.5px solid ${i === 0 ? WF.accent : WF.line}`, background: i === 0 ? WF.accentBg : WF.paper, borderRadius: 4, display: 'flex', alignItems: 'center', gap: 8 }}>
              <Avatar size={22} />
              <T size={11}>{n}</T>
            </div>
          ))}
        </div>
        <div style={{ borderTop: `1px solid ${WF.line}`, paddingTop: 8 }}>
          <Btn small ghost style={{ width: '100%', justifyContent: 'flex-start', textAlign: 'left' }}>+ Create new person</Btn>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6 }}>
          <Btn small>Cancel</Btn>
          <Btn small primary>Link</Btn>
        </div>
      </div>
    </div>
  );
}

// B — Marriage form (multi-field)
function RelDialogB() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, padding: 18, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div>
        <H level={1}>Add marriage</H>
        <T size={11} color={WF.ink3}>Sarah Chen + ___</T>
      </div>
      <Input label="Spouse" required value="🔍 Alex Tan · 1987–" />
      <div style={{ display: 'flex', gap: 8 }}>
        <Input label="Start date" required placeholder="2015-06-12" />
        <Input label="Location" placeholder="Boston, MA" />
      </div>
      <div>
        <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4, display: 'block' }}>Status</T>
        <div style={{ display: 'flex', gap: 4 }}>
          {['Ongoing', 'Divorced', 'Widowed', 'Annulled', 'Separated'].map((s, i) => (
            <div key={s} style={{ flex: 1, padding: '6px 4px', textAlign: 'center', border: `1.5px solid ${i === 0 ? WF.accent : WF.ink3}`, background: i === 0 ? WF.accentBg : WF.paper, borderRadius: 4, fontSize: 10, color: i === 0 ? WF.accent : WF.ink }}>
              {s}
            </div>
          ))}
        </div>
      </div>
      <Input label="End date (if not ongoing)" placeholder="—" />
      <div style={{ padding: 8, background: WF.paper2, border: `1px dashed ${WF.ink4}`, borderRadius: 4, fontSize: 11, color: WF.ink2 }}>
        💡 If "Widowed", we can auto-fill end date from the spouse's death date.
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6, borderTop: `1px solid ${WF.line}`, paddingTop: 10 }}>
        <Btn small>Cancel</Btn>
        <Btn small primary>Save marriage</Btn>
      </div>
    </div>
  );
}

// C — Delete confirmation
function RelDialogC() {
  return (
    <div style={{ width: '100%', height: '100%', background: 'rgba(0,0,0,0.08)', padding: 16, fontFamily: WF.body, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      <div style={{ width: '100%', maxWidth: 340, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 8, boxShadow: '4px 4px 0 rgba(0,0,0,0.1)', padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: WF.accentBg, border: `1.5px solid ${WF.accent}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: WF.accent, fontWeight: 700 }}>!</div>
          <div style={{ flex: 1 }}>
            <H level={2}>Delete Sarah Chen?</H>
            <T size={11} color={WF.ink3}>Deletion is permanent. These things will happen:</T>
          </div>
        </div>
        <div style={{ border: `1.5px dashed ${WF.accent}`, borderRadius: 5, padding: 10, background: WF.paper2 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5, fontSize: 11 }}>
            <div>• 2 biological parent links severed <T size={10} color={WF.ink3}>(David, Linda)</T></div>
            <div>• 2 child links severed <T size={10} color={WF.ink3}>(Liam, Mia)</T></div>
            <div>• 1 marriage deleted <T size={10} color={WF.ink3}>(with Alex Tan)</T></div>
            <div>• 1 sibling link severed</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 0' }}>
          <div style={{ width: 14, height: 14, border: `1.5px solid ${WF.ink}`, borderRadius: 3 }} />
          <T size={11}>I understand this can't be undone beyond the session.</T>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6 }}>
          <Btn small>Cancel</Btn>
          <Btn small primary>Delete permanently</Btn>
        </div>
      </div>
    </div>
  );
}

// ─── People list ─────────────
function PeopleListA() {
  const rows = [
    ['Chen', 'David', 'Mar 1960', '—', 'M'],
    ['Chen', 'Margaret', 'Aug 1932', 'Apr 2015', 'F'],
    ['Chen', 'Michael', '1991', '—', 'M'],
    ['Chen', 'Robert', 'Jan 1930', 'Nov 2008', 'M'],
    ['Chen', 'Sarah', 'Mar 1988', '—', 'F'],
    ['Chen-Tan', 'Liam', '2018', '—', 'M'],
    ['Chen-Tan', 'Mia', '2020', '—', 'F'],
    ['Park', 'Eva', 'Jul 1935', '—', 'F'],
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, padding: 18, fontFamily: WF.body, display: 'flex', flexDirection: 'column', gap: 12, overflow: 'hidden' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <H level={1}>All people <T size={12} color={WF.ink3}>(8)</T></H>
        <Btn small primary>+ Add</Btn>
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <div style={{ flex: 1, border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '5px 9px', fontSize: 11, color: WF.ink3 }}>🔍 filter…</div>
        <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '5px 9px', fontSize: 11 }}>Born: any ▾</div>
        <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '5px 9px', fontSize: 11 }}>Deceased ▾</div>
      </div>
      <div style={{ border: `1.5px solid ${WF.line}`, borderRadius: 5, overflow: 'hidden' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1.3fr 1.2fr 1.2fr 0.6fr', padding: '8px 12px', background: WF.paper2, fontSize: 10, fontWeight: 700, color: WF.ink2, textTransform: 'uppercase', letterSpacing: 0.6 }}>
          <span>Last ↓</span><span>First</span><span>Born</span><span>Died</span><span>Sex</span>
        </div>
        {rows.map((r, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '1.3fr 1.3fr 1.2fr 1.2fr 0.6fr', padding: '8px 12px', borderTop: `1px solid ${WF.line}`, fontSize: 11, background: i % 2 ? WF.paper2 : WF.paper }}>
            <span style={{ fontWeight: 600 }}>{r[0]}</span>
            <span>{r[1]}</span>
            <span style={{ color: WF.ink2 }}>{r[2]}</span>
            <span style={{ color: WF.ink2 }}>{r[3]}</span>
            <span style={{ color: WF.ink3 }}>{r[4]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// B — Card grid
function PeopleListB() {
  const people = ['DC', 'MC', 'MC', 'RC', 'SC', 'LT', 'MT', 'EP', 'JP'];
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, padding: 18, fontFamily: WF.body, display: 'flex', flexDirection: 'column', gap: 12, overflow: 'hidden' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <H level={1}>People</H>
        <div style={{ display: 'flex', gap: 6 }}>
          <Btn small ghost>▦</Btn><Btn small>☰</Btn><Btn small primary>+ Add</Btn>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        {people.map((p, i) => (
          <div key={i} style={{ padding: 10, border: `1.5px solid ${WF.line}`, borderRadius: 6, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, background: WF.paper }}>
            <Avatar size={44} initials={p} />
            <Line w="80%" h={7} />
            <Line w="50%" h={6} />
          </div>
        ))}
      </div>
    </div>
  );
}

// C — Unified search
function PeopleListC() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, padding: 18, fontFamily: WF.body, display: 'flex', flexDirection: 'column', gap: 10, overflow: 'hidden' }}>
      <H level={1}>Find someone</H>
      <div style={{ border: `1.5px solid ${WF.ink}`, borderRadius: 6, padding: '10px 12px', fontSize: 13, color: WF.ink2, display: 'flex', alignItems: 'center', gap: 8 }}>
        🔍<span style={{ color: WF.ink }}>chen</span><span style={{ background: WF.accent, width: 1.5, height: 14 }} />
      </div>
      <div style={{ display: 'flex', gap: 6, fontSize: 10 }}>
        <Tag accent>5 matches</Tag>
        <Tag>born 1900–2025</Tag>
        <Tag>any gender</Tag>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {['David Chen · 1960–', 'Margaret Chen · 1932–2015 ✝', 'Michael Chen · 1991–', 'Robert Chen · 1930–2008 ✝', 'Sarah Chen · 1988–'].map((n, i) => (
          <div key={n} style={{ padding: '7px 10px', border: `1.5px solid ${i === 0 ? WF.accent : WF.line}`, background: i === 0 ? WF.accentBg : WF.paper, borderRadius: 5, display: 'flex', alignItems: 'center', gap: 10 }}>
            <Avatar size={30} />
            <div style={{ flex: 1 }}>
              <T size={12} weight={600}>{n.split(' · ')[0]}</T>
              <div><T size={10} color={WF.ink3}>{n.split(' · ').slice(1).join(' · ')}</T></div>
            </div>
            <T size={11} color={WF.ink3}>→</T>
          </div>
        ))}
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ padding: 8, border: `1.5px dashed ${WF.ink4}`, borderRadius: 5, textAlign: 'center', fontSize: 11, color: WF.ink3 }}>
        Not finding them? <span style={{ color: WF.accent }}>+ Add a new person</span>
      </div>
    </div>
  );
}

// ─── Empty states ─────────────
function EmptyA() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.dotGrid, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: WF.body, padding: 30 }}>
      <div style={{ textAlign: 'center', maxWidth: 320 }}>
        <div style={{ fontFamily: WF.hand, fontSize: 42, color: WF.ink, marginBottom: 10, lineHeight: 1 }}>Your tree is empty</div>
        <T size={12} color={WF.ink3}>Start with yourself, a parent, or any ancestor.<br />You can build out in any direction from there.</T>
        <div style={{ marginTop: 20 }}>
          <Btn primary style={{ padding: '10px 18px', fontSize: 13 }}>+ Add first person</Btn>
        </div>
        <div style={{ marginTop: 12 }}>
          <T size={11} color={WF.ink3}>or <span style={{ color: WF.accent, textDecoration: 'underline' }}>import a GEDCOM file</span></T>
        </div>
      </div>
    </div>
  );
}

function EmptyB() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: WF.body, padding: 20 }}>
      <div style={{ display: 'flex', gap: 12 }}>
        {[
          { t: 'Start fresh', sub: 'Add the first person', primary: true },
          { t: 'Import GEDCOM', sub: 'From another app' },
          { t: 'Import JSON', sub: 'Restore a backup' },
        ].map((c) => (
          <div key={c.t} style={{ width: 120, padding: 14, border: `1.5px ${c.primary ? 'solid' : 'dashed'} ${c.primary ? WF.accent : WF.ink3}`, background: c.primary ? WF.accentBg : WF.paper, borderRadius: 6, textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
            <div style={{ fontSize: 22 }}>{c.primary ? '✦' : '⇣'}</div>
            <H level={3}>{c.t}</H>
            <T size={10} color={WF.ink3}>{c.sub}</T>
          </div>
        ))}
      </div>
    </div>
  );
}

function EmptyC() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper2, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: WF.body, padding: 24 }}>
      <div style={{ width: 300, padding: 20, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 8, boxShadow: '3px 3px 0 rgba(0,0,0,0.08)', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ fontFamily: WF.hand, fontSize: 24, lineHeight: 1, color: WF.ink }}>Tell me about you.</div>
        <T size={11} color={WF.ink3}>We'll build the tree outward from here.</T>
        <Input label="First name" required placeholder="" />
        <Input label="Last name" required placeholder="" />
        <Input label="Birth year" placeholder="e.g. 1990" />
        <Btn small primary>Plant my tree 🌱</Btn>
        <div style={{ textAlign: 'center' }}>
          <T size={10} color={WF.ink3}>Already have data? <span style={{ color: WF.accent }}>Import instead</span></T>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  AddPersonA, AddPersonB, AddPersonC,
  RelDialogA, RelDialogB, RelDialogC,
  PeopleListA, PeopleListB, PeopleListC,
  EmptyA, EmptyB, EmptyC,
});
