// Mid-fi profile (person + phantom) and Add Person (quick + full + edit).

// ─── Profile header ───────────────────────────────────────
function ProfileHeader({ name, nee, dates, place, age, deceased, initials, tone, phantom }) {
  if (phantom) {
    return (
      <div style={{ padding: '20px 20px 14px', display: 'flex', flexDirection: 'column', gap: 12, background: M.paper2, borderBottom: `1px solid ${M.line}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 56, height: 56, borderRadius: '50%',
            border: `1px dashed ${M.ink5}`,
            background: 'repeating-linear-gradient(45deg, transparent 0 5px, rgba(0,0,0,0.04) 5px 6px)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: M.ink3, fontFamily: M.serif, fontSize: 26, fontWeight: 600,
          }}>?</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: M.serif, fontSize: 18, fontWeight: 600, color: M.ink2, fontStyle: 'italic', letterSpacing: -0.2 }}>
              Unknown parent
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 5 }}>
              <Tag tone="ghost">Phantom</Tag>
              <Tag tone="neutral">Shared by 2</Tag>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ padding: '20px 20px 14px', display: 'flex', flexDirection: 'column', gap: 10, borderBottom: `1px solid ${M.line}` }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <Avatar size={64} initials={initials} tone={tone} deceased={deceased} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: M.serif, fontSize: 22, fontWeight: 600, color: M.ink, letterSpacing: -0.3, lineHeight: 1.15 }}>
            {name}
          </div>
          {nee && <div style={{ fontSize: 12, color: M.ink3, fontStyle: 'italic', marginTop: 2 }}>née {nee}</div>}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6, flexWrap: 'wrap' }}>
            <span style={{ fontFamily: M.mono, fontSize: 11, color: M.ink2 }}>{dates}</span>
            {age && <span style={{ fontSize: 11, color: M.ink3 }}>· {age}</span>}
            {deceased && <Tag tone="ghost">Deceased</Tag>}
          </div>
          {place && <div style={{ fontSize: 11.5, color: M.ink3, marginTop: 4 }}>{place}</div>}
        </div>
        <Button size="sm" variant="ghost" icon={<Icon name="more" size={14} />} />
      </div>
    </div>
  );
}

// ─── Person profile (full mid-fi) ─────────────────────────
function MProfile({ tab = 'Relationships' }) {
  return (
    <div style={{ width: '100%', height: '100%', background: M.paper, fontFamily: M.ui, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <ProfileHeader
        name="Sarah Chen" nee="Chen" dates="Mar 14, 1988 – present" place="Boston, MA"
        age="age 37" initials="SC" tone="rose"
      />

      <Tabs items={[
        { label: 'Overview' },
        { label: 'Relationships', count: 7 },
        { label: 'Timeline', count: 12 },
        { label: 'Notes' },
      ]} active={tab} style={{ padding: '0 20px' }} />

      <div style={{ flex: 1, padding: 18, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div>
          <SectionHead title="Biological parents" count="2 / 2" action={
            <Button size="sm" variant="ghost" icon={<Icon name="edit" size={11} />}>Edit</Button>
          } />
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            <PersonChip name="David Chen" sub="1960 –" initials="DC" tone="blue" />
            <PersonChip name="Linda Park" sub="1962 –" initials="LP" tone="sand" />
          </div>
        </div>

        <div>
          <SectionHead title="Adoptive parents" count="none" action={
            <Button size="sm" variant="ghost" icon={<Icon name="plus" size={11} />}>Add</Button>
          } />
          <div style={{
            padding: '8px 12px', border: `1px dashed ${M.line2}`, borderRadius: 6,
            fontSize: 11.5, color: M.ink3, fontStyle: 'italic',
          }}>
            None recorded.
          </div>
        </div>

        <div>
          <SectionHead title="Marriages" count="1 ongoing" action={
            <Button size="sm" variant="ghost" icon={<Icon name="plus" size={11} />}>Add</Button>
          } />
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '10px 12px', background: M.paper, border: `1px solid ${M.line}`, borderRadius: 7,
          }}>
            <Avatar size={32} initials="AT" tone="sage" />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: M.ink, fontFamily: M.serif }}>Alex Tan</div>
              <div style={{ fontSize: 10.5, color: M.ink3, fontFamily: M.mono, marginTop: 1 }}>m. Sep 12, 2015 · Boston · ongoing</div>
            </div>
            <Tag tone="ok">Current</Tag>
          </div>
        </div>

        <div>
          <SectionHead title="Children" count="1 bio · 1 adoptive" action={
            <Button size="sm" variant="ghost" icon={<Icon name="plus" size={11} />}>Add</Button>
          } />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <PersonChip name="Liam Chen-Tan" sub="2018 – · biological" initials="LC" tone="sand" />
            <PersonChip name="Emma Chen-Tan" sub="2015 – · adopted Mar 2017" initials="EC" tone="coral" kind="adoptive" />
          </div>
        </div>

        <div>
          <SectionHead title="Siblings" count="1 full · 0 half" action={<Tag tone="ghost">Auto</Tag>} />
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            <PersonChip name="Michael Chen" sub="full · 1991 –" initials="MC" tone="blue" />
          </div>
        </div>

        <div>
          <SectionHead title="Stepparents" count="1" action={
            <Button size="sm" variant="ghost" icon={<Icon name="plus" size={11} />}>Add</Button>
          } />
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            <PersonChip name="Bob Stein" sub="step · via Linda" initials="BS" tone="neutral" kind="step" />
          </div>
        </div>
      </div>

      <div style={{ padding: '12px 18px', borderTop: `1px solid ${M.line}`, background: M.paper2,
        display: 'flex', gap: 6, alignItems: 'center' }}>
        <Button size="sm" variant="primary" icon={<Icon name="link" size={13} />}>Add relationship</Button>
        <Button size="sm" variant="ghost" icon={<Icon name="focus" size={13} />}>Focus in tree</Button>
        <div style={{ flex: 1 }} />
        <Button size="sm" variant="ghost" icon={<Icon name="edit" size={13} />}>Edit</Button>
      </div>
    </div>
  );
}

// ─── Phantom profile ──────────────────────────────────────
function MProfilePhantom() {
  return (
    <div style={{ width: '100%', height: '100%', background: M.paper, fontFamily: M.ui, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <ProfileHeader phantom />
      <Tabs items={[
        { label: 'Overview', disabled: true },
        { label: 'Relationships' },
        { label: 'Timeline', disabled: true },
        { label: 'Notes', disabled: true },
      ]} active="Relationships" style={{ padding: '0 20px' }} />

      <div style={{ flex: 1, padding: 18, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <Alert tone="coral" icon="sparkle" title="Identify this person">
          This is a placeholder linking siblings. Resolve it to a real person, create a new named ancestor, or leave it as &ldquo;Unknown&rdquo; — sibling links are preserved either way.
          <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
            <Button size="sm" variant="primary">Merge into existing…</Button>
            <Button size="sm">Create new</Button>
          </div>
        </Alert>

        <div>
          <SectionHead title="Inferred children" count="2 siblings linked" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <PersonChip name="Sarah Chen" sub="sibling link · 1988 –" initials="SC" tone="rose" kind="phantom" />
            <PersonChip name="Michael Chen" sub="sibling link · 1991 –" initials="MC" tone="blue" kind="phantom" />
          </div>
        </div>

        <div>
          <SectionHead title="Spouse" count="not recorded" />
          <div style={{
            padding: '8px 12px', border: `1px dashed ${M.line2}`, borderRadius: 6,
            fontSize: 11.5, color: M.ink3, fontStyle: 'italic',
          }}>
            None recorded — identify this person first to add spouse.
          </div>
        </div>
      </div>

      <div style={{ padding: '12px 18px', borderTop: `1px solid ${M.line}`, background: M.paper2,
        display: 'flex', gap: 6 }}>
        <Button size="sm" variant="ghost" icon={<Icon name="focus" size={13} />}>Focus in tree</Button>
        <div style={{ flex: 1 }} />
        <Button size="sm" variant="destructive" icon={<Icon name="trash" size={13} />}>Delete phantom</Button>
      </div>
    </div>
  );
}

// ─── Quick Add popover ───────────────────────────────────
function MQuickAdd() {
  return (
    <div style={{ width: '100%', height: '100%', background: M.paper2, padding: 24, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: M.ui }}>
      <div style={{
        width: 320, background: M.paper, borderRadius: 10, border: `1px solid ${M.line2}`,
        boxShadow: M.popShadow, padding: 18, display: 'flex', flexDirection: 'column', gap: 13,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontFamily: M.serif, fontSize: 17, fontWeight: 600, color: M.ink, letterSpacing: -0.2 }}>Quick add</div>
          <Icon name="close" size={14} color={M.ink3} />
        </div>

        <Field label="Full name" required>
          <Input value="Sarah Chen" />
        </Field>

        <div style={{ display: 'flex', gap: 8 }}>
          <Field label="Born" style={{ flex: 1 }}>
            <Input placeholder="YYYY or c. 1880" value="1988" />
          </Field>
          <Field label="Died" style={{ flex: 1 }}>
            <Input placeholder="—" />
          </Field>
        </div>

        <Field label="Gender">
          <Segmented full items={['Female', 'Male', 'Non-binary', '?']} active="Female" />
        </Field>

        <Alert tone="warn" icon="warn">
          <b>Possible match:</b> Sarah Chen · 1988 — already in tree. <a style={{ color: M.coral, textDecoration: 'underline' }}>View →</a>
        </Alert>

        <Button variant="primary" full>Add &amp; open profile</Button>
        <div style={{ textAlign: 'center', fontSize: 11, color: M.ink3 }}>
          Need more fields? <a style={{ color: M.coral }}>Open full form →</a>
        </div>
      </div>
    </div>
  );
}

// ─── Full Add / Edit form ─────────────────────────────────
function MFullAdd({ mode = 'add' }) {
  return (
    <div style={{ width: '100%', height: '100%', background: M.paper, padding: 22, fontFamily: M.ui, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div>
        <div style={{ fontFamily: M.serif, fontSize: 20, fontWeight: 600, color: M.ink, letterSpacing: -0.3 }}>
          {mode === 'edit' ? 'Edit person' : 'Add a person'}
        </div>
        <div style={{ fontSize: 12, color: M.ink3, marginTop: 3 }}>
          First &amp; last name required. Approximate dates (c. 1880, &ldquo;1955&rdquo;) accepted.
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <Field label="First name" required><Input value={mode === 'edit' ? 'Sarah' : ''} placeholder="Sarah" /></Field>
        <Field label="Last name" required><Input value={mode === 'edit' ? 'Chen' : ''} placeholder="Chen" /></Field>
        <Field label="Birth surname (née)"><Input value={mode === 'edit' ? 'Chen' : ''} placeholder="optional" /></Field>
        <Field label="Gender"><Select value={mode === 'edit' ? 'Female' : 'Select…'} /></Field>
        <Field label="Birth date" hint="YYYY-MM-DD or 'c. 1880'"><Input value={mode === 'edit' ? '1988-03-14' : ''} icon="cake" placeholder="1988-03-14" /></Field>
        <Field label="Birth place"><Input value={mode === 'edit' ? 'Boston, MA' : ''} icon="map" placeholder="City, State" /></Field>
        <Field label="Death date"><Input placeholder="optional" /></Field>
        <Field label="Death place"><Input placeholder="optional" /></Field>
      </div>

      <Field label="Photo">
        <div style={{
          height: 70, border: `1px dashed ${M.line2}`, borderRadius: 7, background: M.paper2,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          color: M.ink3, fontSize: 12,
        }}>
          <Icon name="upload" size={16} />
          Drop a photo, or <a style={{ color: M.coral, textDecoration: 'underline' }}>browse files</a>
          <span style={{ fontFamily: M.mono, fontSize: 10, color: M.ink4 }}>JPG · PNG · WEBP · 5MB</span>
        </div>
      </Field>

      <Field label="Notes">
        <Textarea
          value={mode === 'edit' ? 'Born in Boston, the elder of two siblings. Studied biology at Tufts; works in pediatric oncology research at Dana-Farber. Married Alex in 2015; adopted Emma the same year.' : ''}
          placeholder="Biographical details, sources, stories…"
          rows={4}
          count={mode === 'edit' ? 248 : 0}
        />
      </Field>

      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between', borderTop: `1px solid ${M.line}`, paddingTop: 12 }}>
        {mode === 'edit'
          ? <Button variant="destructive" icon={<Icon name="trash" size={13} />}>Delete person…</Button>
          : <span />
        }
        <div style={{ display: 'flex', gap: 6 }}>
          <Button>Cancel</Button>
          <Button variant="primary">{mode === 'edit' ? 'Save changes' : 'Save person'}</Button>
        </div>
      </div>
    </div>
  );
}

// ─── Photo crop step ──────────────────────────────────────
function MPhotoCrop() {
  return (
    <Dialog
      title="Position photo"
      sub="Drag to reposition · scroll to zoom"
      footer={<>
        <Button>Skip</Button>
        <Button variant="primary">Save photo</Button>
      </>}
      w={420}
    >
      <div style={{ position: 'relative', height: 240, background: M.paper2, borderRadius: 8, overflow: 'hidden', border: `1px solid ${M.line2}` }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(135deg, #d8d2c4 0%, #c4beb1 50%, #ece2cd 100%)',
          backgroundImage: 'repeating-linear-gradient(45deg, transparent 0 8px, rgba(255,255,255,0.06) 8px 9px)',
        }} />
        {/* circular crop mask */}
        <div style={{
          position: 'absolute', inset: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{
            width: 180, height: 180, borderRadius: '50%',
            boxShadow: '0 0 0 9999px rgba(28,26,23,0.45)',
            border: `2px solid ${M.coral}`,
          }} />
        </div>
        <div style={{ position: 'absolute', bottom: 10, right: 10, display: 'flex', gap: 4 }}>
          <Button size="sm">−</Button>
          <Button size="sm">+</Button>
        </div>
      </div>
      <Field label="Zoom">
        <div style={{ height: 4, background: M.line2, borderRadius: 2, position: 'relative' }}>
          <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', width: '38%', background: M.coral, borderRadius: 2 }} />
          <div style={{ position: 'absolute', left: '38%', top: -5, width: 14, height: 14, borderRadius: '50%', background: M.paper, border: `1.5px solid ${M.coral}`, transform: 'translateX(-7px)' }} />
        </div>
      </Field>
    </Dialog>
  );
}

Object.assign(window, { ProfileHeader, MProfile, MProfilePhantom, MQuickAdd, MFullAdd, MPhotoCrop });
