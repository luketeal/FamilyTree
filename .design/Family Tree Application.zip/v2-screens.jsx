// V2 — Profile (2C tabbed) with adoptive sections + chips,
// V2 Add Person (3C quick + 3A full),
// V2 unified Add Relationship dialog,
// V2 People List (5A + import),
// V2 Empty state (6A).

// ─── Relation chip with optional dashed (adoptive) styling ───
function Chip({ children, dashed, sub }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '4px 9px 4px 4px',
      border: `1.5px ${dashed ? 'dashed' : 'solid'} ${dashed ? WF.accent : WF.line}`,
      background: dashed ? '#fdf3ee' : WF.paper,
      borderRadius: 16, fontFamily: WF.body, fontSize: 11,
    }}>
      <Avatar size={20} />
      <span style={{ fontWeight: 600, color: WF.ink }}>{children}</span>
      {sub && <span style={{ color: WF.ink3, fontSize: 10 }}>· {sub}</span>}
    </div>
  );
}

// ─── 2C v2 — Tabbed profile, Relationships tab open, with adoptive ───
function V2Profile() {
  const tabs = ['Overview', 'Relationships', 'Timeline', 'Notes'];
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 16px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
        <Avatar size={44} initials="SC" />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700 }}>Sarah Chen <T size={11} color={WF.ink3}>(née Chen)</T></div>
          <div style={{ fontSize: 10, color: WF.ink3 }}>1988– · Boston, MA · age 37</div>
        </div>
        <Btn small>⋯</Btn>
      </div>
      <div style={{ display: 'flex', gap: 0, padding: '12px 16px 0', borderBottom: `1.5px solid ${WF.line}` }}>
        {tabs.map((t, i) => (
          <div key={t} style={{ padding: '6px 10px', fontSize: 11, fontWeight: i === 1 ? 700 : 500, color: i === 1 ? WF.accent : WF.ink2, borderBottom: i === 1 ? `2px solid ${WF.accent}` : '2px solid transparent', marginBottom: -1.5 }}>
            {t}
          </div>
        ))}
      </div>

      <div style={{ flex: 1, padding: 14, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 11 }}>
        {/* Bio parents */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <H level={3}>Biological parents</H>
            <T size={10} color={WF.ink3}>2 recorded</T>
          </div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            <Chip sub="1960–">David Chen</Chip>
            <Chip sub="1962–">Linda Park</Chip>
          </div>
        </div>

        {/* Adoptive parents — empty slot */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <H level={3}>Adoptive parents</H>
            <T size={10} color={WF.ink3}>none</T>
          </div>
          <div style={{ padding: '6px 10px', border: `1.5px dashed ${WF.ink4}`, borderRadius: 16, fontSize: 10, color: WF.ink3, textAlign: 'center', maxWidth: 140 }}>
            + Add adoptive parent
          </div>
        </div>

        {/* Spouses */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <H level={3}>Spouses</H>
            <T size={10} color={WF.ink3}>1 ongoing</T>
          </div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            <Chip sub="m. 2015 · ongoing">Alex Tan</Chip>
          </div>
        </div>

        {/* Children — mixed bio & adoptive */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <H level={3}>Children</H>
            <T size={10} color={WF.ink3}>1 bio · 1 adoptive</T>
          </div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            <Chip sub="2018–">Liam</Chip>
            <Chip dashed sub="adopted 2017">Emma</Chip>
          </div>
        </div>

        {/* Siblings (auto, full/half labels) */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <H level={3}>Siblings <Tag style={{ marginLeft: 4 }}>Auto</Tag></H>
            <T size={10} color={WF.ink3}>1 full</T>
          </div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            <Chip sub="full · 1991–">Michael Chen</Chip>
          </div>
        </div>

        {/* Stepparents (manual, US-038) */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <H level={3}>Stepparents</H>
            <T size={10} color={WF.ink3}>1</T>
          </div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            <Chip sub="step · via Linda">Bob Stein</Chip>
          </div>
        </div>
      </div>

      <div style={{ padding: '8px 14px', borderTop: `1.5px solid ${WF.line}`, display: 'flex', gap: 6 }}>
        <Btn small primary>+ Add relationship</Btn>
        <Btn small ghost>⌖ Focus in tree</Btn>
      </div>
    </div>
  );
}

// ─── 3C — Quick add popover (default add path) ───
function V2QuickAdd() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper2, padding: 20, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
      <div style={{ width: 280, padding: 16, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 8, boxShadow: '3px 3px 0 rgba(0,0,0,0.08)', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <H level={2}>Quick add</H>
          <T size={14} color={WF.ink3}>✕</T>
        </div>
        <Input label="Full name" required placeholder="Sarah Chen" />
        <div style={{ display: 'flex', gap: 6 }}>
          <Input label="Born" placeholder="YYYY" small />
          <Input label="Died" placeholder="—" small />
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          {['♀', '♂', '⚥', '?'].map((g, i) => (
            <div key={i} style={{ flex: 1, padding: '6px 0', textAlign: 'center', border: `1.5px solid ${i === 0 ? WF.accent : WF.ink3}`, background: i === 0 ? WF.accentBg : WF.paper, borderRadius: 4, fontSize: 13, color: i === 0 ? WF.accent : WF.ink }}>
              {g}
            </div>
          ))}
        </div>
        <div style={{ padding: '6px 8px', background: '#fdf3ee', border: `1.5px dashed ${WF.accent}`, borderRadius: 4, fontSize: 10, color: WF.accent }}>
          ⚠ Possible match: <b>Sarah Chen · 1988</b> · <span style={{ textDecoration: 'underline' }}>view</span>
        </div>
        <Btn small primary>Add & open profile</Btn>
        <div style={{ textAlign: 'center' }}>
          <T size={10} color={WF.ink3}>need more fields? <span style={{ color: WF.accent, textDecoration: 'underline' }}>open full form →</span></T>
        </div>
      </div>
    </div>
  );
}

// ─── 3A — Full single-page form ───
function V2FullAdd() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, padding: 18, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div>
        <H level={1}>Add a person</H>
        <T size={11} color={WF.ink3}>First & last name required. Everything else optional. Approximate dates (c. 1880, "1955") accepted.</T>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <Input label="First name" required placeholder="Sarah" />
        <Input label="Last name" required placeholder="Chen" />
        <Input label="Birth surname (née)" placeholder="optional" />
        <Input label="Gender" value="Female ▾" />
        <Input label="Birth date" placeholder="YYYY-MM-DD or 'c. 1880'" />
        <Input label="Birth place" placeholder="City, State" />
        <Input label="Death date" placeholder="optional" />
        <Input label="Death place" placeholder="optional" />
      </div>
      <div>
        <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Photo</T>
        <Placeholder h={60} label="drop photo · jpg/png/webp · 5mb" style={{ marginTop: 4 }} />
      </div>
      <div>
        <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Notes</T>
        <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 4, padding: 8, marginTop: 4, minHeight: 50 }}>
          <Lines count={2} h={6} />
        </div>
        <T size={10} color={WF.ink3} style={{ float: 'right' }}>0 / 5000</T>
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', borderTop: `1px solid ${WF.line}`, paddingTop: 10 }}>
        <Btn small>Cancel</Btn>
        <Btn small primary>Save person</Btn>
      </div>
    </div>
  );
}

// ─── Unified Add Relationship dialog (Bio/Adoptive toggle) ───
function V2AddRel() {
  return (
    <div style={{ width: '100%', height: '100%', background: 'rgba(0,0,0,0.08)', padding: 16, fontFamily: WF.body, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      <div style={{ width: '100%', maxWidth: 360, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 8, boxShadow: '4px 4px 0 rgba(0,0,0,0.1)', padding: 16, display: 'flex', flexDirection: 'column', gap: 11 }}>
        <H level={2}>Add relationship</H>
        <T size={11} color={WF.ink3}>for Sarah Chen</T>

        {/* Step 1: Kind */}
        <div>
          <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Kind</T>
          <div style={{ display: 'flex', gap: 4, marginTop: 5 }}>
            {['Parent', 'Child', 'Spouse', 'Sibling*'].map((k, i) => (
              <div key={k} style={{ flex: 1, padding: '6px 4px', textAlign: 'center', border: `1.5px solid ${i === 0 ? WF.accent : WF.ink3}`, background: i === 0 ? WF.accentBg : WF.paper, borderRadius: 4, fontSize: 11, color: i === 0 ? WF.accent : WF.ink }}>
                {k}
              </div>
            ))}
          </div>
          <T size={9} color={WF.ink3} style={{ marginTop: 3, display: 'block' }}>* siblings derived automatically from shared parents</T>
        </div>

        {/* Step 2: Bio / Adoptive sub-toggle */}
        <div>
          <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Type</T>
          <div style={{ display: 'flex', gap: 4, marginTop: 5 }}>
            <div style={{ flex: 1, padding: '6px 4px', textAlign: 'center', border: `1.5px solid ${WF.accent}`, background: WF.accentBg, borderRadius: 4, fontSize: 11, color: WF.accent }}>
              ─ Biological
            </div>
            <div style={{ flex: 1, padding: '6px 4px', textAlign: 'center', border: `1.5px dashed ${WF.ink3}`, background: WF.paper, borderRadius: 4, fontSize: 11, color: WF.ink2 }}>
              ┄ Adoptive
            </div>
          </div>
        </div>

        {/* Step 3: who */}
        <div>
          <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Person</T>
          <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '7px 9px', fontSize: 12, color: WF.ink3, marginTop: 5 }}>🔍  Search by name…</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 3, marginTop: 6 }}>
            {['David Chen · 1960–', 'Daniel Chen · 1975–'].map((n, i) => (
              <div key={n} style={{ padding: '5px 7px', border: `1.5px solid ${i === 0 ? WF.accent : WF.line}`, background: i === 0 ? WF.accentBg : WF.paper, borderRadius: 4, fontSize: 11, display: 'flex', alignItems: 'center', gap: 6 }}>
                <Avatar size={20} /><span>{n}</span>
              </div>
            ))}
            <div style={{ padding: '5px 7px', borderTop: `1px solid ${WF.line}`, fontSize: 11, color: WF.accent }}>
              + Create new person…
            </div>
          </div>
        </div>

        {/* Adoption-date field appears only when Adoptive selected — shown collapsed */}
        <div style={{ padding: '6px 8px', background: WF.paper2, border: `1px dashed ${WF.ink4}`, borderRadius: 4, fontSize: 10, color: WF.ink3 }}>
          💡 Switch to <b>Adoptive</b> to add an optional adoption date.
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6 }}>
          <Btn small>Cancel</Btn>
          <Btn small primary>Link</Btn>
        </div>
      </div>
    </div>
  );
}

// ─── 5A v2 — People list with import/export ───
function V2PeopleList() {
  const rows = [
    ['Chen', 'David', 'Mar 1960', '—', 'M', false],
    ['Chen', 'Emma', '2015', '—', 'F', true], // adoptive child
    ['Chen', 'Margaret', 'Aug 1932', 'Apr 2015', 'F', false],
    ['Chen', 'Michael', '1991', '—', 'M', false],
    ['Chen', 'Robert', 'Jan 1930', 'Nov 2008', 'M', false],
    ['Chen', 'Sarah', 'Mar 1988', '—', 'F', false],
    ['Chen-Tan', 'Liam', '2018', '—', 'M', false],
    ['Park', 'Eva', 'Jul 1935', '—', 'F', false],
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, padding: 18, fontFamily: WF.body, display: 'flex', flexDirection: 'column', gap: 12, overflow: 'hidden' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <H level={1}>All people <T size={12} color={WF.ink3}>(8)</T></H>
        <div style={{ display: 'flex', gap: 6 }}>
          <Btn small>⇣ Import</Btn>
          <Btn small>⇡ Export</Btn>
          <Btn small primary>+ Add</Btn>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <div style={{ flex: 1, border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '5px 9px', fontSize: 11, color: WF.ink3 }}>🔍 filter by name…</div>
        <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '5px 9px', fontSize: 11 }}>Born: any ▾</div>
        <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '5px 9px', fontSize: 11 }}>Status ▾</div>
      </div>
      <div style={{ border: `1.5px solid ${WF.line}`, borderRadius: 5, overflow: 'hidden' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1.3fr 1.2fr 1.2fr 0.6fr 0.7fr', padding: '8px 12px', background: WF.paper2, fontSize: 10, fontWeight: 700, color: WF.ink2, textTransform: 'uppercase', letterSpacing: 0.6 }}>
          <span>Last ↓</span><span>First</span><span>Born</span><span>Died</span><span>Sex</span><span>Tags</span>
        </div>
        {rows.map((r, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '1.3fr 1.3fr 1.2fr 1.2fr 0.6fr 0.7fr', padding: '8px 12px', borderTop: `1px solid ${WF.line}`, fontSize: 11, background: i % 2 ? WF.paper2 : WF.paper, alignItems: 'center' }}>
            <span style={{ fontWeight: 600 }}>{r[0]}</span>
            <span>{r[1]}</span>
            <span style={{ color: WF.ink2 }}>{r[2]}</span>
            <span style={{ color: WF.ink2 }}>{r[3]}</span>
            <span style={{ color: WF.ink3 }}>{r[4]}</span>
            <span>{r[5] ? <Tag accent>Adopt.</Tag> : null}</span>
          </div>
        ))}
      </div>

      {/* Import/export dropdown sketch */}
      <div style={{ display: 'flex', gap: 10 }}>
        <div style={{ flex: 1, padding: 10, border: `1.5px dashed ${WF.ink3}`, borderRadius: 6, background: WF.paper2 }}>
          <T size={10} weight={700} style={{ textTransform: 'uppercase', letterSpacing: 0.6, color: WF.ink2 }}>⇣ Import</T>
          <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 4, fontSize: 11 }}>
            <div>· <b>GEDCOM</b> (.ged) from another genealogy app</div>
            <div>· <b>JSON</b> backup from this app</div>
            <div style={{ color: WF.ink3, fontSize: 10 }}>preview shown before commit · merge / overwrite / skip per conflict</div>
          </div>
        </div>
        <div style={{ flex: 1, padding: 10, border: `1.5px dashed ${WF.ink3}`, borderRadius: 6, background: WF.paper2 }}>
          <T size={10} weight={700} style={{ textTransform: 'uppercase', letterSpacing: 0.6, color: WF.ink2 }}>⇡ Export</T>
          <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 4, fontSize: 11 }}>
            <div>· <b>GEDCOM</b> for portability</div>
            <div>· <b>JSON + photos zip</b> for backup</div>
            <div>· <b>PDF</b> of tree or profile</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── 6A — Empty state ───
function V2Empty() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.dotGrid, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: WF.body, padding: 30 }}>
      <div style={{ textAlign: 'center', maxWidth: 340 }}>
        <div style={{ fontFamily: WF.hand, fontSize: 42, color: WF.ink, marginBottom: 10, lineHeight: 1 }}>Your tree is empty</div>
        <T size={12} color={WF.ink3}>Start with yourself, a parent, or any ancestor.<br />You can build out in any direction from there.</T>
        <div style={{ marginTop: 22 }}>
          <Btn primary style={{ padding: '10px 18px', fontSize: 13 }}>+ Add first person</Btn>
        </div>
        <div style={{ marginTop: 14 }}>
          <T size={11} color={WF.ink3}>or import: <span style={{ color: WF.accent, textDecoration: 'underline' }}>GEDCOM</span> · <span style={{ color: WF.accent, textDecoration: 'underline' }}>JSON backup</span></T>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { V2Profile, V2QuickAdd, V2FullAdd, V2AddRel, V2PeopleList, V2Empty });
