// Wireframe primitives — shared low-fi building blocks.
// B&W with a single coral accent for key actions.

const WF = {
  ink: '#1a1a1a',
  ink2: '#4a4a4a',
  ink3: '#8a8a8a',
  ink4: '#c4c4c4',
  paper: '#ffffff',
  paper2: '#fafaf7',
  line: '#d9d6cf',
  line2: '#e8e5de',
  accent: '#e06a4a',
  accentBg: '#fbe9e2',
  hatch: 'repeating-linear-gradient(45deg, transparent 0 4px, rgba(0,0,0,0.05) 4px 5px)',
  hatchDark: 'repeating-linear-gradient(45deg, transparent 0 3px, rgba(0,0,0,0.12) 3px 4px)',
  dotGrid: 'radial-gradient(circle, #d9d6cf 1px, transparent 1px) 0 0 / 16px 16px',
  hand: '"Caveat", "Comic Sans MS", cursive',
  body: '"Inter", system-ui, sans-serif',
  mono: '"JetBrains Mono", "IBM Plex Mono", monospace',
};

// Rounded rectangle with hand-ish 1.5px border
function Box({ children, style = {}, dashed, accent, filled, ...rest }) {
  return (
    <div
      {...rest}
      style={{
        border: `1.5px ${dashed ? 'dashed' : 'solid'} ${accent ? WF.accent : WF.ink}`,
        borderRadius: 6,
        background: filled ? WF.paper2 : WF.paper,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// Simulated text line
function Line({ w = '80%', h = 8, style = {} }) {
  return (
    <div
      style={{
        width: w,
        height: h,
        background: WF.ink4,
        borderRadius: h / 2,
        ...style,
      }}
    />
  );
}

// A stack of text lines (paragraph placeholder)
function Lines({ count = 3, w = '100%', gap = 6, h = 6, style = {} }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap, ...style }}>
      {Array.from({ length: count }).map((_, i) => (
        <Line key={i} w={i === count - 1 ? '60%' : w} h={h} />
      ))}
    </div>
  );
}

// Avatar circle placeholder
function Avatar({ size = 40, initials, style = {} }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        border: `1.5px solid ${WF.ink}`,
        background: WF.paper2,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: WF.body,
        fontSize: size * 0.32,
        fontWeight: 600,
        color: WF.ink2,
        flexShrink: 0,
        ...style,
      }}
    >
      {initials || (
        <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="8" r="4" stroke={WF.ink3} strokeWidth="1.5" />
          <path d="M4 21c0-4 4-7 8-7s8 3 8 7" stroke={WF.ink3} strokeWidth="1.5" />
        </svg>
      )}
    </div>
  );
}

// A button
function Btn({ children, primary, ghost, small, style = {}, ...rest }) {
  const pad = small ? '5px 10px' : '8px 14px';
  const fs = small ? 11 : 12;
  const bg = primary ? WF.accent : ghost ? 'transparent' : WF.paper;
  const color = primary ? '#fff' : WF.ink;
  const border = ghost ? 'none' : `1.5px solid ${primary ? WF.accent : WF.ink}`;
  return (
    <button
      {...rest}
      style={{
        padding: pad,
        fontSize: fs,
        fontFamily: WF.body,
        fontWeight: 500,
        background: bg,
        color,
        border,
        borderRadius: 5,
        cursor: 'pointer',
        letterSpacing: 0.1,
        ...style,
      }}
    >
      {children}
    </button>
  );
}

// Tag / label pill
function Tag({ children, accent, style = {} }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '2px 7px',
        fontSize: 10,
        fontFamily: WF.body,
        fontWeight: 500,
        border: `1px solid ${accent ? WF.accent : WF.ink3}`,
        color: accent ? WF.accent : WF.ink2,
        background: accent ? WF.accentBg : 'transparent',
        borderRadius: 3,
        letterSpacing: 0.3,
        textTransform: 'uppercase',
        ...style,
      }}
    >
      {children}
    </span>
  );
}

// Section label (hand-written style annotation)
function Annotation({ children, style = {} }) {
  return (
    <div
      style={{
        fontFamily: WF.hand,
        fontSize: 16,
        color: WF.accent,
        transform: 'rotate(-2deg)',
        lineHeight: 1,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// Heading text
function H({ children, level = 2, style = {} }) {
  const sizes = { 1: 20, 2: 15, 3: 12, 4: 10 };
  return (
    <div
      style={{
        fontFamily: WF.body,
        fontSize: sizes[level],
        fontWeight: level <= 2 ? 700 : 600,
        color: WF.ink,
        letterSpacing: level >= 3 ? 0.8 : 0,
        textTransform: level >= 3 ? 'uppercase' : 'none',
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// Plain text
function T({ children, size = 12, color, weight, style = {} }) {
  return (
    <span
      style={{
        fontFamily: WF.body,
        fontSize: size,
        color: color || WF.ink2,
        fontWeight: weight || 400,
        ...style,
      }}
    >
      {children}
    </span>
  );
}

// Input field
function Input({ label, value, placeholder, w = '100%', required, small }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, width: w }}>
      {label && (
        <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>
          {label}
          {required && <span style={{ color: WF.accent }}> *</span>}
        </T>
      )}
      <div
        style={{
          border: `1.5px solid ${WF.ink3}`,
          borderRadius: 4,
          padding: small ? '6px 8px' : '8px 10px',
          fontSize: small ? 11 : 12,
          fontFamily: WF.body,
          color: value ? WF.ink : WF.ink4,
          background: WF.paper,
          minHeight: small ? 14 : 16,
        }}
      >
        {value || placeholder || ' '}
      </div>
    </div>
  );
}

// Arrow / callout pointing to something
function ArrowNote({ children, style = {}, direction = 'left' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, ...style }}>
      {direction === 'left' && (
        <svg width="28" height="16" viewBox="0 0 28 16" fill="none">
          <path d="M27 8 Q14 2, 2 10 M2 10 l4 -3 M2 10 l5 2" stroke={WF.accent} strokeWidth="1.2" fill="none" strokeLinecap="round" />
        </svg>
      )}
      <span style={{ fontFamily: WF.hand, fontSize: 15, color: WF.accent, lineHeight: 1 }}>{children}</span>
      {direction === 'right' && (
        <svg width="28" height="16" viewBox="0 0 28 16" fill="none">
          <path d="M1 8 Q14 2, 26 10 M26 10 l-5 -2 M26 10 l-4 3" stroke={WF.accent} strokeWidth="1.2" fill="none" strokeLinecap="round" />
        </svg>
      )}
    </div>
  );
}

// Placeholder image block with diagonal hatch
function Placeholder({ w = '100%', h = 80, label, style = {} }) {
  return (
    <div
      style={{
        width: w,
        height: h,
        background: WF.hatch,
        border: `1.5px solid ${WF.ink3}`,
        borderRadius: 4,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: WF.mono,
        fontSize: 10,
        color: WF.ink3,
        textTransform: 'uppercase',
        letterSpacing: 1,
        ...style,
      }}
    >
      {label}
    </div>
  );
}

Object.assign(window, {
  WF, Box, Line, Lines, Avatar, Btn, Tag, Annotation, H, T, Input, ArrowNote, Placeholder,
});
