// Mid-fi shell: top-bar, rail, tree views (Explore / Pedigree / Descendants).

// ─── Top bar ──────────────────────────────────────────────
function MTopBar() {
  return (
    <div style={{
      height: 52, borderBottom: `1px solid ${M.line}`,
      display: 'flex', alignItems: 'center', padding: '0 18px', gap: 14,
      background: M.paper, flexShrink: 0,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
        <div style={{
          width: 28, height: 28, borderRadius: 7, background: M.coral,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontFamily: M.serif, fontSize: 16, fontWeight: 700, letterSpacing: -0.5,
        }}>C</div>
        <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
          <span style={{ fontFamily: M.serif, fontSize: 15, fontWeight: 600, color: M.ink, letterSpacing: -0.2 }}>The Chen Tree</span>
          <span style={{ fontFamily: M.mono, fontSize: 9.5, color: M.ink4, letterSpacing: 0.3 }}>42 PEOPLE · 5 GENERATIONS</span>
        </div>
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ flex: '0 0 320px' }}>
        <Input icon="search" placeholder="Search people, places, dates…" />
      </div>
      <Button size="sm" variant="ghost" icon={<Icon name="undo" size={14} />}>Undo</Button>
      <Button size="sm" icon={<Icon name="plus" size={14} />} variant="primary">Add person</Button>
    </div>
  );
}

// ─── Rail ─────────────────────────────────────────────────
function MRail({ active = 'tree' }) {
  const items = [
    { k: 'tree',   l: 'Tree',    i: 'tree' },
    { k: 'people', l: 'People',  i: 'list' },
    { k: 'rel',    l: 'Relate',  i: 'link' },
    { k: 'imp',    l: 'Import',  i: 'download' },
  ];
  return (
    <div style={{
      width: 64, borderRight: `1px solid ${M.line}`, background: M.paper2,
      display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '14px 0', gap: 4,
      flexShrink: 0,
    }}>
      {items.map((it) => {
        const a = it.k === active;
        return (
          <div key={it.k} style={{
            width: 50, padding: '8px 0', textAlign: 'center', borderRadius: 7,
            background: a ? M.paper : 'transparent',
            border: a ? `1px solid ${M.line}` : '1px solid transparent',
            color: a ? M.ink : M.ink3,
            fontFamily: M.ui, fontSize: 10.5, fontWeight: 500,
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            boxShadow: a ? '0 1px 2px rgba(28,26,23,0.04)' : 'none',
          }}>
            <Icon name={it.i} size={18} />
            {it.l}
          </div>
        );
      })}
      <div style={{ flex: 1 }} />
      <div style={{
        width: 50, padding: '8px 0', textAlign: 'center', borderRadius: 7,
        color: M.ink3, fontSize: 10.5, fontFamily: M.ui,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
      }}>
        <Icon name="settings" size={18} />
        Settings
      </div>
    </div>
  );
}

// ─── Tree view-mode toggle ────────────────────────────────
function ViewToggle({ mode = 'Explore' }) {
  return (
    <Segmented
      items={[
        { label: 'Explore', icon: 'sparkle' },
        { label: 'Pedigree', icon: 'chev_l' },
        { label: 'Descendants', icon: 'chev_d' },
      ]}
      active={mode}
    />
  );
}

// ─── Tree node ────────────────────────────────────────────
function Node({ name, years, place, focused, deceased, sex, tone = 'neutral', initials, small, badge, phantom }) {
  if (phantom) {
    return (
      <div style={{
        width: small ? 142 : 168,
        height: small ? 56 : 68,
        borderRadius: 9,
        border: `1px dashed ${M.ink5}`,
        background: 'repeating-linear-gradient(45deg, transparent 0 5px, rgba(0,0,0,0.025) 5px 6px)',
        padding: '8px 10px',
        display: 'flex', alignItems: 'center', gap: 9,
        fontFamily: M.ui,
      }}>
        <div style={{
          width: small ? 30 : 36, height: small ? 30 : 36, borderRadius: '50%',
          border: `1px dashed ${M.ink5}`, background: M.paper,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: M.ink3, fontFamily: M.serif, fontSize: 18, fontWeight: 600,
        }}>?</div>
        <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.2, minWidth: 0 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: M.ink3, fontStyle: 'italic' }}>Unknown parent</span>
          <span style={{ fontSize: 10, color: M.coral, fontWeight: 500, marginTop: 1 }}>Identify →</span>
        </div>
      </div>
    );
  }
  const w = small ? 142 : 172;
  const h = small ? 56 : 70;
  return (
    <div style={{
      width: w, height: h,
      background: focused ? M.coralBg : M.paper,
      border: `1.5px solid ${focused ? M.coral : M.line2}`,
      borderRadius: 9,
      padding: '8px 10px',
      display: 'flex', alignItems: 'center', gap: 10,
      fontFamily: M.ui, position: 'relative',
      boxShadow: focused ? '0 1px 2px rgba(201,100,66,0.15), 0 6px 16px rgba(201,100,66,0.12)' : '0 1px 2px rgba(28,26,23,0.03)',
    }}>
      <Avatar size={small ? 32 : 40} initials={initials} tone={tone} deceased={deceased} />
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.15, minWidth: 0, flex: 1 }}>
        <span style={{ fontFamily: M.serif, fontSize: small ? 12.5 : 14, fontWeight: 600, color: M.ink,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', letterSpacing: -0.1 }}>{name}</span>
        <span style={{ fontFamily: M.mono, fontSize: 10, color: M.ink3, marginTop: 2 }}>{years}</span>
        {place && !small && <span style={{ fontSize: 10, color: M.ink4, marginTop: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{place}</span>}
      </div>
      {badge && (
        <div style={{ position: 'absolute', top: -7, right: -7 }}>
          <Tag tone={badge === 'A' ? 'teal' : 'accent'} style={{ padding: '2px 6px', fontSize: 9 }}>{badge}</Tag>
        </div>
      )}
    </div>
  );
}

// ─── Tree toolbar (overlay on canvas) ─────────────────────
function TreeToolbar({ mode, breadcrumb, right }) {
  return (
    <>
      <div style={{
        position: 'absolute', top: 14, left: 16, right: 16,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
        zIndex: 3, pointerEvents: 'none',
      }}>
        <div style={{ pointerEvents: 'auto' }}><ViewToggle mode={mode} /></div>
        <div style={{ display: 'flex', gap: 6, pointerEvents: 'auto' }}>
          {right || (
            <>
              <Button size="sm" icon={<Icon name="print" size={13} />}>PDF</Button>
              <Button size="sm" icon={<Icon name="fit" size={13} />}>Fit</Button>
            </>
          )}
        </div>
      </div>
      {breadcrumb && (
        <div style={{
          position: 'absolute', top: 56, left: 16,
          background: M.paper, border: `1px solid ${M.line}`, borderRadius: 6,
          padding: '5px 10px', fontFamily: M.ui, fontSize: 11, color: M.ink2,
          boxShadow: '0 1px 2px rgba(28,26,23,0.04)',
          display: 'flex', alignItems: 'center', gap: 6,
          zIndex: 3,
        }}>
          {breadcrumb}
        </div>
      )}
    </>
  );
}

// ─── Legend ───────────────────────────────────────────────
function Legend({ pos = 'bottom-right' }) {
  const styles = pos === 'bottom-right'
    ? { bottom: 14, right: 16 }
    : { bottom: 14, left: 16 };
  const Row = ({ label, swatch }) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ width: 26 }}>{swatch}</div>
      <span style={{ fontSize: 10.5, color: M.ink2, fontFamily: M.ui }}>{label}</span>
    </div>
  );
  return (
    <div style={{
      position: 'absolute', ...styles, zIndex: 3,
      background: M.paper, border: `1px solid ${M.line}`, borderRadius: 7,
      padding: '8px 11px', boxShadow: '0 1px 2px rgba(28,26,23,0.04)',
      display: 'flex', flexDirection: 'column', gap: 5,
    }}>
      <span style={{ fontSize: 9.5, fontWeight: 700, letterSpacing: 0.6, color: M.ink3, textTransform: 'uppercase', marginBottom: 2 }}>Legend</span>
      <Row label="Biological" swatch={<svg width="26" height="6"><line x1="0" y1="3" x2="26" y2="3" stroke={M.ink} strokeWidth="1.5" /></svg>} />
      <Row label="Adoptive" swatch={<svg width="26" height="6"><line x1="0" y1="3" x2="26" y2="3" stroke={M.teal} strokeWidth="1.5" strokeDasharray="4 3" /></svg>} />
      <Row label="Marriage" swatch={<svg width="26" height="8"><line x1="0" y1="2.5" x2="26" y2="2.5" stroke={M.ink} strokeWidth="1.2" /><line x1="0" y1="5.5" x2="26" y2="5.5" stroke={M.ink} strokeWidth="1.2" /></svg>} />
      <Row label="Step" swatch={<svg width="26" height="6"><line x1="0" y1="3" x2="26" y2="3" stroke={M.step} strokeWidth="1.5" strokeDasharray="2 3" /></svg>} />
    </div>
  );
}

// ─── Mini-map ─────────────────────────────────────────────
function MiniMap() {
  return (
    <div style={{
      position: 'absolute', bottom: 14, left: 16,
      width: 132, height: 86, background: M.paper, border: `1px solid ${M.line}`, borderRadius: 7,
      padding: 6, zIndex: 3, boxShadow: '0 1px 2px rgba(28,26,23,0.04)',
    }}>
      <div style={{ width: '100%', height: '100%', background: M.paper2, borderRadius: 4, position: 'relative', overflow: 'hidden' }}>
        <svg viewBox="0 0 132 86" width="100%" height="100%">
          {[[15,18],[30,30],[45,18],[60,30],[80,18],[95,30],[110,18]].map(([x,y],i) =>
            <circle key={i} cx={x} cy={y} r="2" fill={M.ink4} />)}
          {[[22,55],[45,55],[68,55],[90,55]].map(([x,y],i) =>
            <circle key={'b'+i} cx={x} cy={y} r="2" fill={M.ink4} />)}
          {/* viewport rect */}
          <rect x="20" y="14" width="50" height="30" fill="none" stroke={M.coral} strokeWidth="1.2" />
        </svg>
      </div>
    </div>
  );
}

// ─── Couple bracket (marriage union with kids attached) ───
// Renders two parent boxes with a double-line marriage bar and a dropdown to children.
// Used in Pedigree and Descendants modes.

// ═════════════════════════════════════════════════════════
//  EXPLORE MODE — free-form canvas with phantom parent
// ═════════════════════════════════════════════════════════
function MExplore() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: M.paper2, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, backgroundImage: M.dotGrid, opacity: 0.7 }} />

      <TreeToolbar mode="Explore" breadcrumb={<>
        <span style={{ color: M.ink4 }}>Tree of</span>
        <span style={{ fontWeight: 600, color: M.ink }}>Sarah Chen</span>
        <Icon name="chev_r" size={11} color={M.ink4} />
        <span>Immediate family</span>
      </>} />

      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        {/* Phantom → Sarah & Michael (bio dashed) */}
        <path d="M285 150 Q 240 215, 200 270" stroke={M.ink5} strokeWidth="1.5" fill="none" strokeDasharray="3 3" />
        <path d="M335 150 Q 380 215, 420 270" stroke={M.ink5} strokeWidth="1.5" fill="none" strokeDasharray="3 3" />
        {/* Marriage Sarah ↔ Alex (double horizontal) */}
        <line x1={250} y1={306} x2={300} y2={306} stroke={M.ink2} strokeWidth="1.2" />
        <line x1={250} y1={310} x2={300} y2={310} stroke={M.ink2} strokeWidth="1.2" />
        {/* Sarah & Alex → Liam (bio) */}
        <path d="M270 340 Q 270 395, 270 430" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        {/* Sarah → Emma (adoptive teal dashed) */}
        <path d="M275 340 Q 350 395, 405 430" stroke={M.teal} strokeWidth="1.5" fill="none" strokeDasharray="5 3" />
        {/* Sarah → daughter via past marriage (step indicator example removed) */}
      </svg>

      {/* Phantom (gen above) */}
      <div style={{ position: 'absolute', left: 250, top: 100 }}><Node phantom /></div>

      {/* Siblings */}
      <div style={{ position: 'absolute', left: 110, top: 270 }}>
        <Node name="Sarah Chen" years="1988 — present" place="Boston, MA" focused initials="SC" tone="rose" />
      </div>
      <div style={{ position: 'absolute', left: 360, top: 270 }}>
        <Node name="Michael Chen" years="1991 — present" place="San Francisco, CA" initials="MC" tone="blue" />
      </div>

      {/* Spouse Alex — small node next to Sarah */}
      <div style={{ position: 'absolute', left: 295, top: 280 }}>
        <Node small name="Alex Tan" years="1987 — present" initials="AT" tone="sage" />
      </div>

      {/* Kids */}
      <div style={{ position: 'absolute', left: 198, top: 430 }}>
        <Node small name="Liam Chen-Tan" years="2018 — present" initials="LC" tone="sand" />
      </div>
      <div style={{ position: 'absolute', left: 350, top: 430 }}>
        <Node small name="Emma Chen-Tan" years="2015 — present" initials="EC" tone="coral" badge="A" />
      </div>

      {/* "Expand next gen" handle on phantom edge */}
      <div style={{
        position: 'absolute', left: 295, top: 200,
        width: 22, height: 22, borderRadius: '50%',
        background: M.paper, border: `1px solid ${M.line2}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: M.ink3, boxShadow: '0 1px 2px rgba(28,26,23,0.06)', cursor: 'pointer', zIndex: 2,
      }}>
        <Icon name="plus" size={11} />
      </div>

      <Legend />
      <MiniMap />

      {/* Zoom controls */}
      <div style={{
        position: 'absolute', top: 56, right: 16, zIndex: 3,
        display: 'flex', flexDirection: 'column',
        background: M.paper, border: `1px solid ${M.line}`, borderRadius: 7, overflow: 'hidden',
        boxShadow: '0 1px 2px rgba(28,26,23,0.04)',
      }}>
        {['plus', 'minus', 'focus'].map((n, i) => (
          <div key={n} style={{
            width: 30, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: M.ink2, cursor: 'pointer',
            borderTop: i ? `1px solid ${M.line}` : 'none',
          }}>
            <Icon name={n} size={14} />
          </div>
        ))}
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════
//  PEDIGREE MODE — ancestors only, rigid right-branching
// ═════════════════════════════════════════════════════════
function MPedigree() {
  const Box = ({ x, y, name, years, deceased, focused, tone, initials, unknown }) => {
    if (unknown) {
      return (
        <div style={{
          position: 'absolute', left: x, top: y,
          width: 132, height: 44, borderRadius: 7,
          border: `1px dashed ${M.line2}`, background: M.paper2,
          padding: '6px 10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          color: M.ink4, fontFamily: M.ui, fontSize: 11, fontStyle: 'italic',
        }}>
          <Icon name="plus" size={11} /> Unknown
        </div>
      );
    }
    return (
      <div style={{ position: 'absolute', left: x, top: y }}>
        <div style={{
          width: 132, height: 44, borderRadius: 7,
          background: focused ? M.coralBg : M.paper,
          border: `1.5px solid ${focused ? M.coral : M.line2}`,
          padding: '6px 9px', display: 'flex', alignItems: 'center', gap: 7,
          fontFamily: M.ui, boxShadow: '0 1px 2px rgba(28,26,23,0.03)',
        }}>
          <Avatar size={28} initials={initials} tone={tone} deceased={deceased} />
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.15, minWidth: 0 }}>
            <span style={{ fontFamily: M.serif, fontSize: 12, fontWeight: 600, color: M.ink, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</span>
            <span style={{ fontFamily: M.mono, fontSize: 9.5, color: M.ink3, marginTop: 1 }}>{years}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: M.paper2, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, backgroundImage: M.dotGrid, opacity: 0.7 }} />

      <TreeToolbar mode="Pedigree" breadcrumb={<>
        <span style={{ color: M.ink4 }}>Ancestors of</span>
        <span style={{ fontWeight: 600, color: M.ink }}>Sarah Chen</span>
        <Tag tone="neutral" style={{ marginLeft: 4 }}>4 GEN</Tag>
      </>} />

      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        {/* Sarah → David, Linda */}
        <path d="M165 314 H 200" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M200 220 V 408" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M200 220 H 240" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M200 408 H 240" stroke={M.ink2} strokeWidth="1.5" fill="none" />

        {/* David → Robert, Margaret */}
        <path d="M372 220 H 400" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M400 168 V 272" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M400 168 H 440" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M400 272 H 440" stroke={M.ink2} strokeWidth="1.5" fill="none" />

        {/* Linda → Eva, James */}
        <path d="M372 408 H 400" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M400 356 V 460" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M400 356 H 440" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M400 460 H 440" stroke={M.ink2} strokeWidth="1.5" fill="none" />

        {/* Robert → great-grandparents */}
        <path d="M572 168 H 600" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 138 V 198" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 138 H 632" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 198 H 632" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        {/* Margaret → ggp */}
        <path d="M572 272 H 600" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 242 V 302" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 242 H 632" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 302 H 632" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        {/* Eva → ggp */}
        <path d="M572 356 H 600" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 326 V 386" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 326 H 632" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 386 H 632" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        {/* James → ggp */}
        <path d="M572 460 H 600" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 430 V 490" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 430 H 632" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M600 490 H 632" stroke={M.ink2} strokeWidth="1.5" fill="none" />
      </svg>

      {/* Gen 0 — Sarah */}
      <Box x={32} y={292} name="Sarah Chen" years="1988 –" focused initials="SC" tone="rose" />
      {/* Gen 1 — Parents */}
      <Box x={240} y={198} name="David Chen" years="1960 –" initials="DC" tone="blue" />
      <Box x={240} y={386} name="Linda Park" years="1962 –" initials="LP" tone="sand" />
      {/* Gen 2 — Grandparents */}
      <Box x={440} y={146} name="Robert Chen" years="1930 – 2008" initials="RC" tone="neutral" deceased />
      <Box x={440} y={250} name="Margaret Chen" years="1932 – 2015" initials="MC" tone="rose" deceased />
      <Box x={440} y={334} name="Eva Park" years="1935 –" initials="EP" tone="sage" />
      <Box x={440} y={438} name="James Park" years="1933 – 2019" initials="JP" tone="neutral" deceased />
      {/* Gen 3 — Great-grandparents */}
      <Box x={632} y={116} name="Henry Chen" years="c. 1900 – 1972" initials="HC" tone="neutral" deceased />
      <Box x={632} y={176} name="Alice Wu" years="c. 1905 – 1980" initials="AW" tone="rose" deceased />
      <Box x={632} y={220} unknown />
      <Box x={632} y={280} unknown />
      <Box x={632} y={304} unknown />
      <Box x={632} y={364} name="Ji-Won Park" years="c. 1908 – 1988" initials="JP" tone="sand" deceased />
      <Box x={632} y={408} name="Soo Lee" years="c. 1910 – 1992" initials="SL" tone="rose" deceased />
      <Box x={632} y={468} unknown />

      <Legend pos="bottom-right" />
    </div>
  );
}

// ═════════════════════════════════════════════════════════
//  DESCENDANTS MODE — top-down with inline spouses
// ═════════════════════════════════════════════════════════
function MDescendants() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: M.paper2, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, backgroundImage: M.dotGrid, opacity: 0.7 }} />

      <TreeToolbar mode="Descendants" breadcrumb={<>
        <span style={{ color: M.ink4 }}>Descendants of</span>
        <span style={{ fontWeight: 600, color: M.ink }}>Margaret Chen</span>
        <Tag tone="neutral" style={{ marginLeft: 4 }}>4 GEN</Tag>
      </>} />

      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        {/* Margaret marriage to Robert (double-line) */}
        <line x1={310} y1={130} x2={388} y2={130} stroke={M.ink2} strokeWidth="1.2" />
        <line x1={310} y1={134} x2={388} y2={134} stroke={M.ink2} strokeWidth="1.2" />
        {/* Down to David */}
        <path d="M349 144 V 220 H 349 V 240" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        {/* David ↔ Linda double */}
        <line x1={310} y1={272} x2={388} y2={272} stroke={M.ink2} strokeWidth="1.2" />
        <line x1={310} y1={276} x2={388} y2={276} stroke={M.ink2} strokeWidth="1.2" />
        {/* David+Linda → Sarah, Michael */}
        <path d="M349 286 V 322" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M180 322 H 530" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M180 322 V 360" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M530 322 V 360" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        {/* Sarah ↔ Alex */}
        <line x1={140} y1={398} x2={222} y2={398} stroke={M.ink2} strokeWidth="1.2" />
        <line x1={140} y1={402} x2={222} y2={402} stroke={M.ink2} strokeWidth="1.2" />
        {/* Sarah → Liam (bio) and Emma (adoptive teal) */}
        <path d="M180 412 V 458" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M120 458 H 240" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M120 458 V 488" stroke={M.ink2} strokeWidth="1.5" fill="none" />
        <path d="M240 458 V 488" stroke={M.teal} strokeWidth="1.5" fill="none" strokeDasharray="5 3" />
      </svg>

      {/* Margaret + Robert (root couple) */}
      <div style={{ position: 'absolute', left: 244, top: 92 }}>
        <Node small name="Margaret Chen" years="1932 – 2015" initials="MC" tone="rose" deceased />
      </div>
      <div style={{ position: 'absolute', left: 388, top: 92 }}>
        <Node small name="Robert Chen" years="1930 – 2008" initials="RC" tone="neutral" deceased />
      </div>

      {/* Gen 1 — David + Linda */}
      <div style={{ position: 'absolute', left: 244, top: 240 }}>
        <Node small name="David Chen" years="1960 –" initials="DC" tone="blue" />
      </div>
      <div style={{ position: 'absolute', left: 388, top: 240 }}>
        <Node small name="Linda Park" years="1962 –" initials="LP" tone="sand" />
      </div>

      {/* Gen 2 — Sarah + Alex (focused), Michael solo */}
      <div style={{ position: 'absolute', left: 75, top: 360 }}>
        <Node small name="Sarah Chen" years="1988 –" focused initials="SC" tone="rose" />
      </div>
      <div style={{ position: 'absolute', left: 222, top: 360 }}>
        <Node small name="Alex Tan" years="1987 –" initials="AT" tone="sage" />
      </div>
      <div style={{ position: 'absolute', left: 460, top: 360 }}>
        <Node small name="Michael Chen" years="1991 –" initials="MC" tone="blue" />
      </div>

      {/* Gen 3 — Liam + Emma (adoptive) */}
      <div style={{ position: 'absolute', left: 50, top: 488 }}>
        <Node small name="Liam Chen-Tan" years="2018 –" initials="LC" tone="sand" />
      </div>
      <div style={{ position: 'absolute', left: 170, top: 488 }}>
        <Node small name="Emma Chen-Tan" years="2015 –" initials="EC" tone="coral" badge="A" />
      </div>

      {/* + Add child handle on Michael */}
      <div style={{
        position: 'absolute', left: 525, top: 410, zIndex: 2,
        padding: '4px 9px', background: M.paper, border: `1px dashed ${M.line2}`, borderRadius: 14,
        fontFamily: M.ui, fontSize: 11, color: M.ink3, display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer',
      }}>
        <Icon name="plus" size={11} /> Add child
      </div>

      <Legend />
    </div>
  );
}

// ─── Shell wrapper ────────────────────────────────────────
function MShell({ children, profile, profileWidth = 360, active = 'tree' }) {
  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: M.paper, overflow: 'hidden' }}>
      <MTopBar />
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <MRail active={active} />
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>{children}</div>
        {profile && <div style={{ width: profileWidth, borderLeft: `1px solid ${M.line}`, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>{profile}</div>}
      </div>
    </div>
  );
}

Object.assign(window, { MTopBar, MRail, MShell, ViewToggle, Node, MExplore, MPedigree, MDescendants, Legend, MiniMap });
