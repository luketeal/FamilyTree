// V2 wireframes — selected directions, with adoptive relationships
// integrated as a first-class type (dashed edges, dashed chips).

// ─────────────────────────────────────────────────────────────
// Shared chrome
// ─────────────────────────────────────────────────────────────
function V2TopBar() {
  return (
    <div style={{ height: 44, borderBottom: `1.5px solid ${WF.ink}`, display: 'flex', alignItems: 'center', padding: '0 16px', gap: 14, background: WF.paper, flexShrink: 0 }}>
      <div style={{ fontFamily: WF.hand, fontSize: 22, color: WF.ink, lineHeight: 1 }}>The Chen Tree</div>
      <div style={{ flex: 1 }} />
      <div style={{ flex: '0 0 320px', border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '6px 10px', display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: WF.ink3, fontFamily: WF.body }}>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
          <circle cx="11" cy="11" r="7" stroke={WF.ink3} strokeWidth="2" />
          <path d="m20 20-3-3" stroke={WF.ink3} strokeWidth="2" strokeLinecap="round" />
        </svg>
        Search people…
      </div>
      <Btn small>⎌ Undo</Btn>
      <Btn small primary>+ Add Person</Btn>
    </div>
  );
}

function V2Rail() {
  const items = [
    { label: 'Tree', active: true, icon: '⌂' },
    { label: 'People', icon: '☰' },
    { label: 'Pedigree', icon: '↰' },
    { label: 'Descend.', icon: '↳' },
    { label: 'Relate', icon: '↭' },
  ];
  return (
    <div style={{ width: 54, borderRight: `1.5px solid ${WF.line}`, background: WF.paper2, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 0', gap: 4, flexShrink: 0 }}>
      {items.map((it) => (
        <div key={it.label} style={{ width: 42, padding: '8px 0', textAlign: 'center', borderRadius: 5, background: it.active ? WF.ink : 'transparent', color: it.active ? WF.paper : WF.ink2, fontFamily: WF.body, fontSize: 9, fontWeight: 500 }}>
          <div style={{ fontSize: 16, lineHeight: 1, marginBottom: 3 }}>{it.icon}</div>{it.label}
        </div>
      ))}
      <div style={{ flex: 1 }} />
      <div style={{ width: 42, padding: '8px 0', textAlign: 'center', fontFamily: WF.body, fontSize: 9, color: WF.ink2 }}>
        <div style={{ fontSize: 16, lineHeight: 1, marginBottom: 3 }}>⇅</div>Im/Ex
      </div>
    </div>
  );
}

// Tree node
function V2Node({ name, years, focused, deceased, small, hasAdoptive }) {
  const w = small ? 108 : 130;
  const h = small ? 40 : 48;
  return (
    <div style={{ width: w, height: h, border: `1.5px solid ${focused ? WF.accent : WF.ink}`, background: focused ? WF.accentBg : WF.paper, borderRadius: 5, padding: '6px 10px', display: 'flex', flexDirection: 'column', justifyContent: 'center', fontFamily: WF.body, position: 'relative' }}>
      <div style={{ fontSize: small ? 11 : 12, fontWeight: 600, color: WF.ink, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</div>
      <div style={{ fontSize: 10, color: WF.ink3, marginTop: 2 }}>{years}</div>
      {deceased && <div style={{ position: 'absolute', top: 3, right: 5, fontSize: 8, color: WF.ink3 }}>✝</div>}
      {hasAdoptive && <div style={{ position: 'absolute', bottom: -6, right: 4, fontSize: 8, fontWeight: 700, color: WF.accent, background: WF.paper, padding: '0 3px', borderRadius: 2, border: `1px solid ${WF.accent}` }}>A+B</div>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 1B v2 — Infinite node-graph canvas with adoption case shown
// ─────────────────────────────────────────────────────────────
function V2Tree() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: WF.dotGrid, overflow: 'hidden' }}>
      {/* Top toolbar */}
      <div style={{ position: 'absolute', top: 10, left: 14, right: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 2 }}>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center', background: WF.paper, border: `1.5px solid ${WF.line}`, borderRadius: 5, padding: '4px 8px', fontFamily: WF.body, fontSize: 10 }}>
          <span style={{ color: WF.ink3 }}>⌂</span><span>David</span>
          <span style={{ color: WF.ink3 }}>›</span><span>Sarah Chen</span>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          <Btn small ghost>Pedigree</Btn>
          <Btn small ghost>Descendants</Btn>
          <Btn small>⛶ Fit</Btn>
        </div>
      </div>

      {/* Legend */}
      <div style={{ position: 'absolute', top: 50, left: 14, padding: '6px 10px', background: WF.paper, border: `1.5px solid ${WF.line}`, borderRadius: 5, display: 'flex', flexDirection: 'column', gap: 3, fontFamily: WF.body, fontSize: 10, color: WF.ink2, zIndex: 2 }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="22" height="4"><line x1="0" y1="2" x2="22" y2="2" stroke={WF.ink} strokeWidth="1.5" /></svg>Biological
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="22" height="4"><line x1="0" y1="2" x2="22" y2="2" stroke={WF.ink} strokeWidth="1.5" strokeDasharray="3 2" /></svg>Adoptive
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="22" height="8"><line x1="0" y1="2" x2="22" y2="2" stroke={WF.ink} strokeWidth="1" /><line x1="0" y1="6" x2="22" y2="6" stroke={WF.ink} strokeWidth="1" /></svg>Marriage
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="22" height="4"><line x1="0" y1="2" x2="22" y2="2" stroke={WF.ink3} strokeWidth="1.5" strokeDasharray="1 2" /></svg>Step
        </span>
      </div>

      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {/* Marriages — double line */}
        <line x1={155} y1={130} x2={175} y2={130} stroke={WF.ink} strokeWidth="1.2" />
        <line x1={155} y1={134} x2={175} y2={134} stroke={WF.ink} strokeWidth="1.2" />
        <line x1={330} y1={110} x2={350} y2={110} stroke={WF.ink} strokeWidth="1.2" />
        <line x1={330} y1={114} x2={350} y2={114} stroke={WF.ink} strokeWidth="1.2" />
        {/* Sarah's marriage to Alex */}
        <line x1={195} y1={364} x2={235} y2={364} stroke={WF.ink} strokeWidth="1.2" />
        <line x1={195} y1={368} x2={235} y2={368} stroke={WF.ink} strokeWidth="1.2" />

        {/* G-parents to parents (biological, solid) */}
        <path d="M100 152 Q 120 200, 150 220" stroke={WF.ink} strokeWidth="1.5" fill="none" />
        <path d="M230 152 Q 230 200, 240 220" stroke={WF.ink} strokeWidth="1.5" fill="none" />
        <path d="M290 132 Q 260 200, 240 220" stroke={WF.ink} strokeWidth="1.5" fill="none" />
        <path d="M400 132 Q 380 200, 340 220" stroke={WF.ink} strokeWidth="1.5" fill="none" />

        {/* Parents to Sarah (focused — coral) */}
        <path d="M155 265 Q 155 310, 175 340" stroke={WF.accent} strokeWidth="1.5" fill="none" />
        <path d="M275 265 Q 245 310, 215 340" stroke={WF.accent} strokeWidth="1.5" fill="none" />

        {/* Sarah & Alex → Liam (biological) */}
        <path d="M215 388 Q 200 420, 165 440" stroke={WF.ink} strokeWidth="1.5" fill="none" />

        {/* Sarah & Alex → Emma (ADOPTIVE — dashed, with label) */}
        <path d="M215 388 Q 250 420, 290 440" stroke={WF.ink} strokeWidth="1.5" fill="none" strokeDasharray="4 3" />
        {/* "(A)" edge label */}
        <rect x={258} y={418} width={20} height={13} rx={2} fill={WF.paper} stroke={WF.accent} strokeWidth="1" />
        <text x={268} y={428} fontFamily="Inter" fontSize="9" fontWeight="700" fill={WF.accent} textAnchor="middle">A</text>

        {/* Step-edge (dotted) — Linda's new partner Bob is step to Sarah */}
        <path d="M340 265 Q 290 320, 215 350" stroke={WF.ink3} strokeWidth="1.2" fill="none" strokeDasharray="1 3" />
      </svg>

      {/* Nodes */}
      <div style={{ position: 'absolute', left: 40, top: 110 }}><V2Node small name="Margaret C." years="1932–2015" deceased /></div>
      <div style={{ position: 'absolute', left: 180, top: 110 }}><V2Node small name="Robert C." years="1930–2008" deceased /></div>
      <div style={{ position: 'absolute', left: 240, top: 90 }}><V2Node small name="Eva Park" years="1935–" /></div>
      <div style={{ position: 'absolute', left: 355, top: 90 }}><V2Node small name="James Park" years="1933–2019" deceased /></div>

      <div style={{ position: 'absolute', left: 90, top: 220 }}><V2Node name="David Chen" years="1960–" /></div>
      <div style={{ position: 'absolute', left: 225, top: 220 }}><V2Node name="Linda Park" years="1962–" /></div>
      {/* Linda's new partner — step to Sarah */}
      <div style={{ position: 'absolute', left: 360, top: 235 }}><V2Node small name="Bob Stein" years="1964–" /></div>

      <div style={{ position: 'absolute', left: 155, top: 340 }}><V2Node name="Sarah Chen" years="1988–" focused /></div>
      <div style={{ position: 'absolute', left: 235, top: 340 }}><V2Node small name="Alex Tan" years="1987–" /></div>

      {/* Children — Liam (bio) and Emma (adoptive) */}
      <div style={{ position: 'absolute', left: 105, top: 440 }}><V2Node small name="Liam" years="2018–" /></div>
      <div style={{ position: 'absolute', left: 245, top: 440 }}><V2Node small name="Emma" years="2015–" hasAdoptive /></div>

      {/* Annotation pointing to dashed edge */}
      <div style={{ position: 'absolute', left: 290, top: 408, zIndex: 2 }}>
        <Annotation style={{ transform: 'rotate(8deg)' }}>dashed = adoptive</Annotation>
      </div>
      <div style={{ position: 'absolute', left: 365, top: 458, zIndex: 2 }}>
        <Annotation style={{ transform: 'rotate(-3deg)', fontSize: 13 }}>"A+B" badge: child has both bio. & adoptive</Annotation>
      </div>

      {/* Mini-map */}
      <div style={{ position: 'absolute', bottom: 14, right: 14, width: 120, height: 80, border: `1.5px solid ${WF.line}`, background: WF.paper, borderRadius: 4, zIndex: 2 }}>
        <div style={{ fontFamily: WF.body, fontSize: 9, color: WF.ink3, padding: '3px 6px', borderBottom: `1px solid ${WF.line}` }}>MINIMAP</div>
        <div style={{ position: 'relative', padding: 6 }}>
          {[...Array(10)].map((_, i) => (
            <div key={i} style={{ position: 'absolute', left: 8 + (i % 5) * 20, top: 4 + Math.floor(i / 5) * 22, width: 9, height: 5, background: i === 5 ? WF.accent : WF.ink3, borderRadius: 1 }} />
          ))}
          <div style={{ position: 'absolute', left: 6, top: 2, width: 50, height: 34, border: `1.5px solid ${WF.accent}`, borderRadius: 2 }} />
        </div>
      </div>

      {/* Zoom */}
      <div style={{ position: 'absolute', bottom: 110, right: 14, display: 'flex', flexDirection: 'column', gap: 4, zIndex: 2 }}>
        <Btn small style={{ width: 28, padding: 4 }}>+</Btn>
        <Btn small style={{ width: 28, padding: 4 }}>−</Btn>
      </div>
    </div>
  );
}

Object.assign(window, { V2TopBar, V2Rail, V2Node, V2Tree });
