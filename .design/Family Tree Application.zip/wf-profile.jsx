// Profile side panel variations.

// A — Scrolling single column
function ProfileA() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 16px', borderBottom: `1.5px solid ${WF.line}`, display: 'flex', alignItems: 'center', gap: 12 }}>
        <Avatar size={52} initials="SC" />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700 }}>Sarah Chen</div>
          <div style={{ fontSize: 11, color: WF.ink3 }}>1988– · age 37</div>
        </div>
        <Btn small>Edit</Btn>
      </div>
      <div style={{ flex: 1, overflow: 'hidden', padding: 14, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <H level={3} style={{ marginBottom: 6 }}>Details</H>
          <div style={{ display: 'grid', gridTemplateColumns: '80px 1fr', rowGap: 5, fontSize: 11 }}>
            <T size={11} color={WF.ink3}>Born</T><T size={11}>Mar 4, 1988 · Boston, MA</T>
            <T size={11} color={WF.ink3}>Gender</T><T size={11}>Female</T>
            <T size={11} color={WF.ink3}>Surname</T><T size={11}>née Chen</T>
          </div>
        </div>
        <div>
          <H level={3} style={{ marginBottom: 6 }}>Biological Parents</H>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {['David Chen · 1960–', 'Linda Park · 1962–'].map((n) => (
              <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 7px', border: `1px solid ${WF.line}`, borderRadius: 4 }}>
                <Avatar size={22} />
                <T size={11}>{n}</T>
              </div>
            ))}
          </div>
        </div>
        <div>
          <H level={3} style={{ marginBottom: 6 }}>Marriages</H>
          <div style={{ padding: '6px 8px', border: `1px solid ${WF.line}`, borderRadius: 4, fontSize: 11 }}>
            <T size={11} weight={600}>Alex Tan</T>
            <div><T size={10} color={WF.ink3}>2015 – ongoing</T></div>
          </div>
        </div>
        <div>
          <H level={3} style={{ marginBottom: 6 }}>Children</H>
          <Lines count={2} h={8} />
        </div>
        <div>
          <H level={3} style={{ marginBottom: 6 }}>Siblings</H>
          <Lines count={2} h={8} />
        </div>
      </div>
      <div style={{ position: 'relative', padding: '10px 16px', borderTop: `1.5px solid ${WF.line}`, display: 'flex', gap: 6 }}>
        <Btn small primary>+ Add relation</Btn>
        <Btn small ghost>⌖ Focus in tree</Btn>
        <div style={{ position: 'absolute', top: -28, right: 8 }}>
          <ArrowNote direction="right" style={{ transform: 'rotate(3deg)' }}>all sections stacked</ArrowNote>
        </div>
      </div>
    </div>
  );
}

// B — Two-column (details left, relations right)
function ProfileB() {
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 16px', borderBottom: `1.5px solid ${WF.line}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 16, fontWeight: 700 }}>Sarah Chen <T size={11} color={WF.ink3}>(née Chen)</T></div>
        <Btn small>Edit</Btn>
      </div>
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <div style={{ width: 180, padding: 14, borderRight: `1.5px solid ${WF.line}`, background: WF.paper2, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Avatar size={90} initials="SC" style={{ alignSelf: 'center' }} />
          <div style={{ fontSize: 10, color: WF.ink3, textAlign: 'center' }}>♀ Female · 1988–</div>
          <div>
            <H level={3} style={{ marginBottom: 4 }}>Born</H>
            <T size={11}>Mar 4, 1988</T><br /><T size={10} color={WF.ink3}>Boston, MA</T>
          </div>
          <div>
            <H level={3} style={{ marginBottom: 4 }}>Notes</H>
            <Lines count={4} h={6} />
          </div>
        </div>
        <div style={{ flex: 1, padding: 14, display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[
            { t: 'Biological Parents', n: 2, add: true },
            { t: 'Marriages', n: 1, add: true },
            { t: 'Children', n: 2, add: true },
            { t: 'Siblings', n: 1, badge: 'Auto' },
          ].map((s) => (
            <div key={s.t}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 5 }}>
                <H level={3}>{s.t}</H>
                {s.badge && <Tag>{s.badge}</Tag>}
                <div style={{ flex: 1 }} />
                {s.add && <Btn small ghost style={{ fontSize: 10, padding: '2px 6px' }}>+ add</Btn>}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                {Array.from({ length: s.n }).map((_, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 6px', border: `1px solid ${WF.line}`, borderRadius: 4 }}>
                    <Avatar size={20} />
                    <Line w="55%" h={7} />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// C — Tabbed
function ProfileC() {
  const tabs = ['Overview', 'Relationships', 'Timeline', 'Notes'];
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 16px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
        <Avatar size={44} initials="SC" />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700 }}>Sarah Chen</div>
          <div style={{ fontSize: 10, color: WF.ink3 }}>1988– · Boston, MA</div>
        </div>
        <Btn small>⋯</Btn>
      </div>
      <div style={{ display: 'flex', gap: 0, padding: '12px 16px 0', borderBottom: `1.5px solid ${WF.line}` }}>
        {tabs.map((t, i) => (
          <div key={t} style={{ padding: '6px 10px', fontSize: 11, fontWeight: i === 1 ? 700 : 500, color: i === 1 ? WF.accent : WF.ink2, borderBottom: i === 1 ? `2px solid ${WF.accent}` : '2px solid transparent', marginBottom: -1.5 }}>
            {t}
          </div>
        ))}
      </div>
      <div style={{ flex: 1, padding: 14, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {[
          { t: 'Bio. parents', n: 2 },
          { t: 'Adoptive parents', n: 0, dashed: true },
          { t: 'Spouses', n: 1 },
          { t: 'Children', n: 2 },
          { t: 'Siblings', n: 1 },
        ].map((s) => (
          <div key={s.t}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
              <H level={3}>{s.t}</H>
              <T size={10} color={WF.ink3}>{s.n === 0 ? 'none' : `${s.n} recorded`}</T>
            </div>
            {s.n > 0 ? (
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                {Array.from({ length: s.n }).map((_, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 8px', border: `1.5px ${s.dashed ? 'dashed' : 'solid'} ${WF.line}`, borderRadius: 16 }}>
                    <Avatar size={18} /><Line w={50} h={6} />
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ padding: '6px 8px', border: `1.5px dashed ${WF.ink4}`, borderRadius: 4, fontSize: 10, color: WF.ink3, textAlign: 'center' }}>
                + Add
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// D — Card stack
function ProfileD() {
  const cards = [
    { t: 'Biology', sub: '2 parents · 1 sibling', color: WF.ink },
    { t: 'Adoption', sub: 'none recorded', color: WF.ink3, dashed: true },
    { t: 'Marriage', sub: '1 spouse · since 2015', color: WF.ink },
    { t: 'Descendants', sub: '2 children', color: WF.ink },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: WF.paper2, fontFamily: WF.body, overflow: 'hidden', display: 'flex', flexDirection: 'column', padding: 14, gap: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 6 }}>
        <Avatar size={56} initials="SC" />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700 }}>Sarah Chen</div>
          <div style={{ fontSize: 10, color: WF.ink3, marginTop: 2 }}>née Chen · 1988– · age 37</div>
          <div style={{ display: 'flex', gap: 4, marginTop: 5 }}>
            <Tag>Female</Tag><Tag>Boston</Tag>
          </div>
        </div>
      </div>
      {cards.map((c) => (
        <div key={c.t} style={{ padding: 10, background: WF.paper, border: `1.5px ${c.dashed ? 'dashed' : 'solid'} ${c.color}`, borderRadius: 6, display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ flex: 1 }}>
            <H level={3}>{c.t}</H>
            <T size={11} color={WF.ink3} style={{ marginTop: 2 }}>{c.sub}</T>
          </div>
          <Btn small ghost>→</Btn>
        </div>
      ))}
      <div style={{ flex: 1 }} />
      <Btn small primary style={{ alignSelf: 'stretch' }}>+ Add Relationship</Btn>
    </div>
  );
}

Object.assign(window, { ProfileA, ProfileB, ProfileC, ProfileD });
