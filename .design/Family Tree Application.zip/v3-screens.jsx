// V3 — View-mode toggle (Explore / Pedigree / Descendants) + phantom-parent siblings

function V3TopBar() {
  return (
    <div style={{ height: 44, borderBottom: `1.5px solid ${WF.ink}`, display: 'flex', alignItems: 'center', padding: '0 16px', gap: 14, background: WF.paper, flexShrink: 0 }}>
      <div style={{ fontFamily: WF.hand, fontSize: 22, color: WF.ink, lineHeight: 1 }}>The Chen Tree</div>
      <div style={{ flex: 1 }} />
      <div style={{ flex: '0 0 280px', border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '6px 10px', fontSize: 12, color: WF.ink3 }}>🔍 Search people…</div>
      <Btn small>⎌ Undo</Btn>
      <Btn small primary>+ Add Person</Btn>
    </div>
  );
}

function V3Rail() {
  const items = [{ l: 'Tree', a: true, i: '⌂' }, { l: 'People', i: '☰' }, { l: 'Relate', i: '↭' }];
  return (
    <div style={{ width: 54, borderRight: `1.5px solid ${WF.line}`, background: WF.paper2, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 0', gap: 4, flexShrink: 0 }}>
      {items.map((it) => (
        <div key={it.l} style={{ width: 42, padding: '8px 0', textAlign: 'center', borderRadius: 5, background: it.a ? WF.ink : 'transparent', color: it.a ? WF.paper : WF.ink2, fontFamily: WF.body, fontSize: 9, fontWeight: 500 }}>
          <div style={{ fontSize: 16, lineHeight: 1, marginBottom: 3 }}>{it.i}</div>{it.l}
        </div>
      ))}
    </div>
  );
}

// View-mode segmented toggle — same across all tree states
function ViewToggle({ mode }) {
  const modes = [
    { k: 'explore', l: 'Explore', i: '✦' },
    { k: 'pedigree', l: 'Pedigree', i: '↰' },
    { k: 'desc', l: 'Descendants', i: '↳' },
  ];
  return (
    <div style={{ display: 'flex', background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 6, overflow: 'hidden', boxShadow: '2px 2px 0 rgba(0,0,0,0.06)' }}>
      {modes.map((m) => (
        <div key={m.k} style={{ padding: '5px 10px', fontSize: 11, fontWeight: 600, borderRight: m.k !== 'desc' ? `1.5px solid ${WF.ink}` : 'none', background: mode === m.k ? WF.ink : WF.paper, color: mode === m.k ? WF.paper : WF.ink, display: 'flex', alignItems: 'center', gap: 5 }}>
          <span>{m.i}</span>{m.l}
        </div>
      ))}
    </div>
  );
}

function TreeNode({ name, years, focused, deceased, small, phantom }) {
  const w = small ? 108 : 126;
  const h = small ? 40 : 46;
  if (phantom) {
    return (
      <div style={{ width: w, height: h, border: `1.5px dashed ${WF.ink3}`, background: 'repeating-linear-gradient(45deg, transparent 0 4px, rgba(0,0,0,0.04) 4px 5px)', borderRadius: 5, padding: '6px 10px', display: 'flex', flexDirection: 'column', justifyContent: 'center', fontFamily: WF.body }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: WF.ink3, fontStyle: 'italic' }}>? Unknown parent</div>
        <div style={{ fontSize: 9, color: WF.ink3, marginTop: 2 }}>phantom · <span style={{ color: WF.accent, textDecoration: 'underline' }}>identify</span></div>
      </div>
    );
  }
  return (
    <div style={{ width: w, height: h, border: `1.5px solid ${focused ? WF.accent : WF.ink}`, background: focused ? WF.accentBg : WF.paper, borderRadius: 5, padding: '6px 10px', display: 'flex', flexDirection: 'column', justifyContent: 'center', fontFamily: WF.body, position: 'relative' }}>
      <div style={{ fontSize: small ? 11 : 12, fontWeight: 600, color: WF.ink, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</div>
      <div style={{ fontSize: 10, color: WF.ink3, marginTop: 2 }}>{years}</div>
      {deceased && <div style={{ position: 'absolute', top: 3, right: 5, fontSize: 8, color: WF.ink3 }}>✝</div>}
    </div>
  );
}

// ─── Explore mode — free-form with phantom parent ───
function V3Explore() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: WF.dotGrid, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 10, left: 14, right: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 2 }}>
        <ViewToggle mode="explore" />
        <Btn small>⛶ Fit</Btn>
      </div>

      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {/* Phantom parent to two siblings */}
        <path d="M220 130 Q 170 200, 130 240" stroke={WF.ink3} strokeWidth="1.5" fill="none" strokeDasharray="3 3" />
        <path d="M260 130 Q 310 200, 350 240" stroke={WF.ink3} strokeWidth="1.5" fill="none" strokeDasharray="3 3" />
        {/* Sarah's marriage to Alex */}
        <line x1={170} y1={283} x2={210} y2={283} stroke={WF.ink} strokeWidth="1.2" />
        <line x1={170} y1={287} x2={210} y2={287} stroke={WF.ink} strokeWidth="1.2" />
        {/* Sarah → Liam */}
        <path d="M195 310 Q 195 355, 195 390" stroke={WF.accent} strokeWidth="1.5" fill="none" />
        {/* Sarah → Emma (adoptive) */}
        <path d="M195 310 Q 260 355, 305 390" stroke={WF.ink} strokeWidth="1.5" fill="none" strokeDasharray="4 3" />
        <rect x={253} y={362} width={18} height={13} rx={2} fill={WF.paper} stroke={WF.accent} strokeWidth="1" />
        <text x={262} y={372} fontFamily="Inter" fontSize="9" fontWeight="700" fill={WF.accent} textAnchor="middle">A</text>
      </svg>

      {/* Phantom parent */}
      <div style={{ position: 'absolute', left: 200, top: 85 }}><TreeNode phantom /></div>

      {/* Two siblings from phantom */}
      <div style={{ position: 'absolute', left: 70, top: 240 }}><TreeNode name="Sarah Chen" years="1988–" focused /></div>
      <div style={{ position: 'absolute', left: 295, top: 240 }}><TreeNode name="Michael Chen" years="1991–" /></div>

      {/* Spouse */}
      <div style={{ position: 'absolute', left: 210, top: 263 }}><TreeNode small name="Alex Tan" years="1987–" /></div>

      {/* Kids */}
      <div style={{ position: 'absolute', left: 140, top: 390 }}><TreeNode small name="Liam" years="2018–" /></div>
      <div style={{ position: 'absolute', left: 260, top: 390 }}><TreeNode small name="Emma" years="2015–" /></div>

      {/* Annotations */}
      <div style={{ position: 'absolute', left: 320, top: 98, zIndex: 2 }}>
        <Annotation style={{ transform: 'rotate(4deg)' }}>phantom parent — links siblings without a named ancestor</Annotation>
      </div>
      <div style={{ position: 'absolute', left: 265, top: 465, zIndex: 2 }}>
        <Annotation style={{ transform: 'rotate(-3deg)' }}>click "identify" to promote to a real person</Annotation>
      </div>
    </div>
  );
}

// ─── Pedigree mode — ancestors only, rigid left-branching ───
function V3Pedigree() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: WF.dotGrid, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 10, left: 14, right: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 2 }}>
        <ViewToggle mode="pedigree" />
        <div style={{ display: 'flex', gap: 4 }}>
          <Btn small>⇡ PDF</Btn>
          <Btn small>⛶ Fit</Btn>
        </div>
      </div>

      <div style={{ position: 'absolute', top: 50, left: 14, padding: '5px 9px', background: WF.paper, border: `1.5px solid ${WF.line}`, borderRadius: 5, fontSize: 10, color: WF.ink2, zIndex: 2 }}>
        <b>Ancestors of Sarah Chen</b> · 4 generations · spouses & siblings hidden
      </div>

      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {/* Gen 1 (parents) */}
        <line x1={155} y1={290} x2={200} y2={290} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={200} y1={200} x2={200} y2={380} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={200} y1={200} x2={240} y2={200} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={200} y1={380} x2={240} y2={380} stroke={WF.ink} strokeWidth="1.5" />
        {/* Gen 2 grandparents */}
        <line x1={365} y1={160} x2={410} y2={160} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={410} y1={110} x2={410} y2={210} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={410} y1={110} x2={450} y2={110} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={410} y1={210} x2={450} y2={210} stroke={WF.ink} strokeWidth="1.5" />

        <line x1={365} y1={240} x2={410} y2={240} stroke={WF.ink} strokeWidth="1.5" strokeDasharray="3 2" />

        <line x1={365} y1={340} x2={410} y2={340} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={410} y1={290} x2={410} y2={390} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={410} y1={290} x2={450} y2={290} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={410} y1={390} x2={450} y2={390} stroke={WF.ink} strokeWidth="1.5" />

        <line x1={365} y1={430} x2={410} y2={430} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={410} y1={480} x2={410} y2={430} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={410} y1={480} x2={450} y2={480} stroke={WF.ink} strokeWidth="1.5" />
      </svg>

      {/* Focused left */}
      <div style={{ position: 'absolute', left: 30, top: 267 }}><TreeNode name="Sarah Chen" years="1988–" focused /></div>

      {/* Parents */}
      <div style={{ position: 'absolute', left: 240, top: 177 }}><TreeNode small name="David Chen" years="1960–" /></div>
      <div style={{ position: 'absolute', left: 240, top: 357 }}><TreeNode small name="Linda Park" years="1962–" /></div>

      {/* Grandparents */}
      <div style={{ position: 'absolute', left: 450, top: 87 }}><TreeNode small name="Robert C." years="'30–'08" deceased /></div>
      <div style={{ position: 'absolute', left: 450, top: 187 }}><TreeNode small name="Margaret C." years="'32–'15" deceased /></div>
      <div style={{ position: 'absolute', left: 450, top: 220 }}>
        <div style={{ padding: '6px 10px', border: `1.5px dashed ${WF.ink4}`, borderRadius: 5, fontSize: 10, color: WF.ink3, width: 108, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          Unknown
        </div>
      </div>
      <div style={{ position: 'absolute', left: 450, top: 267 }}><TreeNode small name="Eva Park" years="1935–" /></div>
      <div style={{ position: 'absolute', left: 450, top: 367 }}><TreeNode small name="James Park" years="'33–'19" deceased /></div>
      <div style={{ position: 'absolute', left: 450, top: 457 }}>
        <div style={{ padding: '6px 10px', border: `1.5px dashed ${WF.ink4}`, borderRadius: 5, fontSize: 10, color: WF.ink3, width: 108, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          + Add ancestor
        </div>
      </div>

      <div style={{ position: 'absolute', left: 250, top: 140, zIndex: 2 }}>
        <Annotation style={{ transform: 'rotate(-3deg)' }}>strict 2-parent branching · empty = Unknown</Annotation>
      </div>
    </div>
  );
}

// ─── Descendants mode — descendants only, rigid top-down ───
function V3Descendants() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: WF.dotGrid, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 10, left: 14, right: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 2 }}>
        <ViewToggle mode="desc" />
        <div style={{ display: 'flex', gap: 4 }}>
          <Btn small>⇡ PDF</Btn>
          <Btn small>⛶ Fit</Btn>
        </div>
      </div>

      <div style={{ position: 'absolute', top: 50, left: 14, padding: '5px 9px', background: WF.paper, border: `1.5px solid ${WF.line}`, borderRadius: 5, fontSize: 10, color: WF.ink2, zIndex: 2 }}>
        <b>Descendants of Margaret Chen</b> · 4 generations · ancestors hidden
      </div>

      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {/* Top — Margaret down to David */}
        <line x1={320} y1={110} x2={320} y2={180} stroke={WF.ink} strokeWidth="1.5" />
        {/* David to children */}
        <line x1={320} y1={230} x2={320} y2={260} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={180} y1={260} x2={460} y2={260} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={180} y1={260} x2={180} y2={300} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={460} y1={260} x2={460} y2={300} stroke={WF.ink} strokeWidth="1.5" />
        {/* Sarah to Liam + Emma(adoptive) */}
        <line x1={180} y1={350} x2={180} y2={390} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={120} y1={390} x2={240} y2={390} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={120} y1={390} x2={120} y2={420} stroke={WF.ink} strokeWidth="1.5" />
        <line x1={240} y1={390} x2={240} y2={420} stroke={WF.ink} strokeWidth="1.5" strokeDasharray="4 3" />
        <rect x={230} y={400} width={18} height={13} rx={2} fill={WF.paper} stroke={WF.accent} strokeWidth="1" />
        <text x={239} y={410} fontFamily="Inter" fontSize="9" fontWeight="700" fill={WF.accent} textAnchor="middle">A</text>
      </svg>

      {/* Root */}
      <div style={{ position: 'absolute', left: 257, top: 64 }}><TreeNode name="Margaret Chen" years="1932–2015" deceased /></div>

      {/* Gen 1 — David with inline spouse */}
      <div style={{ position: 'absolute', left: 257, top: 184, display: 'flex', gap: 4, alignItems: 'center' }}>
        <TreeNode small name="David Chen" years="1960–" />
        <span style={{ fontFamily: WF.body, fontSize: 10, color: WF.ink3 }}>+</span>
        <div style={{ padding: '4px 8px', border: `1px dashed ${WF.ink4}`, borderRadius: 4, fontSize: 10, color: WF.ink3 }}>Linda Park (sp.)</div>
      </div>

      {/* Gen 2 */}
      <div style={{ position: 'absolute', left: 117, top: 304, display: 'flex', gap: 4, alignItems: 'center' }}>
        <TreeNode small name="Sarah Chen" years="1988–" focused />
        <span style={{ fontFamily: WF.body, fontSize: 10, color: WF.ink3 }}>+</span>
        <div style={{ padding: '4px 8px', border: `1px dashed ${WF.ink4}`, borderRadius: 4, fontSize: 10, color: WF.ink3 }}>Alex Tan</div>
      </div>
      <div style={{ position: 'absolute', left: 397, top: 304 }}><TreeNode small name="Michael Chen" years="1991–" /></div>

      {/* Gen 3 */}
      <div style={{ position: 'absolute', left: 65, top: 420 }}><TreeNode small name="Liam" years="2018–" /></div>
      <div style={{ position: 'absolute', left: 185, top: 420 }}><TreeNode small name="Emma" years="2015–" /></div>

      <div style={{ position: 'absolute', left: 380, top: 420, zIndex: 2 }}>
        <Annotation style={{ transform: 'rotate(-4deg)' }}>spouses shown inline (dashed) · their own ancestors hidden</Annotation>
      </div>
    </div>
  );
}

// ─── Add Relationship dialog — Sibling kind, phantom-parent note ───
function V3SiblingDialog() {
  return (
    <div style={{ width: '100%', height: '100%', background: 'rgba(0,0,0,0.08)', padding: 16, fontFamily: WF.body, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      <div style={{ width: '100%', maxWidth: 380, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 8, boxShadow: '4px 4px 0 rgba(0,0,0,0.1)', padding: 16, display: 'flex', flexDirection: 'column', gap: 11 }}>
        <H level={2}>Add relationship</H>
        <T size={11} color={WF.ink3}>for Sarah Chen</T>

        <div>
          <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Kind</T>
          <div style={{ display: 'flex', gap: 4, marginTop: 5 }}>
            {['Parent', 'Child', 'Spouse', 'Sibling'].map((k, i) => (
              <div key={k} style={{ flex: 1, padding: '6px 4px', textAlign: 'center', border: `1.5px solid ${i === 3 ? WF.accent : WF.ink3}`, background: i === 3 ? WF.accentBg : WF.paper, borderRadius: 4, fontSize: 11, color: i === 3 ? WF.accent : WF.ink }}>
                {k}
              </div>
            ))}
          </div>
        </div>

        <div style={{ padding: 9, background: WF.paper2, border: `1.5px dashed ${WF.accent}`, borderRadius: 5, fontSize: 11, color: WF.ink2, lineHeight: 1.5 }}>
          <b style={{ color: WF.accent }}>How siblings work:</b> if Sarah and the other person already share a recorded parent, we'll link them automatically. If not, we'll create an <b>unknown phantom parent</b> connecting them — you can identify that parent later.
        </div>

        <div>
          <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Sibling type</T>
          <div style={{ display: 'flex', gap: 4, marginTop: 5 }}>
            {['Full', 'Half', 'Unknown'].map((s, i) => (
              <div key={s} style={{ flex: 1, padding: '6px 4px', textAlign: 'center', border: `1.5px solid ${i === 0 ? WF.accent : WF.ink3}`, background: i === 0 ? WF.accentBg : WF.paper, borderRadius: 4, fontSize: 11, color: i === 0 ? WF.accent : WF.ink }}>
                {s}
              </div>
            ))}
          </div>
        </div>

        <div>
          <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Sibling</T>
          <div style={{ border: `1.5px solid ${WF.ink3}`, borderRadius: 5, padding: '7px 9px', fontSize: 12, color: WF.ink, marginTop: 5, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Avatar size={20} /> Michael Chen · 1991–
          </div>
        </div>

        <div style={{ padding: 7, background: WF.accentBg, border: `1.5px solid ${WF.accent}`, borderRadius: 4, fontSize: 10, color: WF.accent }}>
          ⓘ Both share <b>David Chen</b> and <b>Linda Park</b> as recorded parents — auto-link will be used (no phantom needed).
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6 }}>
          <Btn small>Cancel</Btn>
          <Btn small primary>Link as siblings</Btn>
        </div>
      </div>
    </div>
  );
}

// ─── Phantom identify flow ───
function V3IdentifyPhantom() {
  return (
    <div style={{ width: '100%', height: '100%', background: 'rgba(0,0,0,0.08)', padding: 16, fontFamily: WF.body, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
      <div style={{ width: '100%', maxWidth: 380, background: WF.paper, border: `1.5px solid ${WF.ink}`, borderRadius: 8, boxShadow: '4px 4px 0 rgba(0,0,0,0.1)', padding: 16, display: 'flex', flexDirection: 'column', gap: 11 }}>
        <H level={2}>Identify phantom parent</H>
        <T size={11} color={WF.ink3}>Sarah and Michael are siblings via an unknown parent.</T>

        <div style={{ padding: 10, border: `1.5px dashed ${WF.ink3}`, background: 'repeating-linear-gradient(45deg, transparent 0 4px, rgba(0,0,0,0.04) 4px 5px)', borderRadius: 5, display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 30, height: 30, borderRadius: '50%', background: WF.paper, border: `1.5px dashed ${WF.ink3}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: WF.ink3, fontWeight: 700 }}>?</div>
          <div style={{ flex: 1, fontSize: 11, color: WF.ink2 }}>
            <b>Phantom parent</b><br />
            <span style={{ color: WF.ink3, fontSize: 10 }}>shared by Sarah Chen · Michael Chen</span>
          </div>
        </div>

        <div>
          <T size={10} color={WF.ink2} weight={600} style={{ textTransform: 'uppercase', letterSpacing: 0.5 }}>Resolve as</T>
          <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 4 }}>
            <div style={{ padding: '8px 10px', border: `1.5px solid ${WF.accent}`, background: WF.accentBg, borderRadius: 5, fontSize: 11 }}>
              <b style={{ color: WF.accent }}>◉ Merge into existing person</b>
              <div style={{ marginTop: 5, border: `1.5px solid ${WF.ink3}`, borderRadius: 4, padding: '6px 8px', fontSize: 11, color: WF.ink3, background: WF.paper }}>🔍 Search by name…</div>
            </div>
            <div style={{ padding: '8px 10px', border: `1.5px solid ${WF.line}`, borderRadius: 5, fontSize: 11, color: WF.ink2 }}>
              ◯ Create a new named person
            </div>
            <div style={{ padding: '8px 10px', border: `1.5px solid ${WF.line}`, borderRadius: 5, fontSize: 11, color: WF.ink2 }}>
              ◯ Keep as "Unknown" — leave phantom in place
            </div>
          </div>
        </div>

        <div style={{ padding: 7, background: WF.paper2, border: `1px dashed ${WF.ink4}`, borderRadius: 4, fontSize: 10, color: WF.ink3 }}>
          Sibling links between Sarah and Michael are preserved either way.
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6 }}>
          <Btn small>Cancel</Btn>
          <Btn small primary>Resolve</Btn>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { V3TopBar, V3Rail, V3Explore, V3Pedigree, V3Descendants, V3SiblingDialog, V3IdentifyPhantom });
